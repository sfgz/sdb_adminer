plugin.tx_sdbadminer_main {
    view {
        templateRootPaths.0 = EXT:sdb_adminer/Resources/Private/Templates/
        partialRootPaths.0 = EXT:sdb_adminer/Resources/Private/Partials/
        layoutRootPaths.0 = EXT:sdb_adminer/Resources/Private/Layouts/
    }
    features {
      requireCHashArgumentForActionArguments = 0
    }
    settings {
        # used in ModelUtility
        displayDateFormat = d.m.Y
        # unused mainpage_uid = {$plugin.sfgz_design.settings.mainpage_uid}
        # unused displayCharset = utf-8
        # used in ModelUtility: mapping data-source for selector fields 
        selector_fieldtypes {
			0 {
				name = textfield
				source = none
			}
			1 {
				name  = radiogroup
				source = flexform
			}
			2  {
				name = selector
				source = flexform
			}
			3  {
				name = filtered_selector
				source = ajax
				break_if_found_in_key = 0
			}
			4  {
				name = checkgroup
				source = flexform
			}
			5  {
				name = password
				source = none
			}
			6  {
				name = label
				source = none
			}
			7  {
				name = passthrough
				source = none
			}
        }
    }
}

plugin.tx_sdbadminer_edlist < plugin.tx_sdbadminer_main

plugin.tx_sdbadminer_edit < plugin.tx_sdbadminer_main

# the pageType 1527806882 appears in views ...
json_update_sdbadminer = PAGE
json_update_sdbadminer {
  config {
    disableAllHeaderCode = 1
    debug = 0
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1527806882
   10 = USER_INT
   10 {
      userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
      extensionName = SdbAdminer
      pluginName = Edit
      vendorName = Sfgz
      controller = Json
	  action = update
      switchableControllerActions {
         Json {
            1 = update
            2 = list
         }
      }
   }
}
json_read_sdbadminer = PAGE
json_read_sdbadminer < json_update_sdbadminer
json_read_sdbadminer {
	typeNum = 1545591292
	10.switchableControllerActions.Json.1 = list
}

page.includeCSS.sdb_adminerCalendar = typo3conf/ext/sdb_adminer/Resources/Public/Css/pureJSCalendar.css
page.includeJS.sdb_adminerCalendar = typo3conf/ext/sdb_adminer/Resources/Public/Scr/pureJSCalendar.js

page.includeJSFooter.sdb_adminer = typo3conf/ext/sdb_adminer/Resources/Public/Scr/sdb_adminer.js


# these classes are only used in auto-generated templates
plugin.tx_sdbadminer._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }

    .tx-sdb-adminer table {
        border-collapse:separate;
        border-spacing:5px 10px;
        margin-left:-5px;
        width:100%;
    }

    .tx-sdb-adminer table th {
        font-weight:bold;
    }

    td {
        vertical-align:top;
    }
    
    table.tx_sdbadminer_editor td {
        vertical-align:baseline;
    }
    
    
    
    /* EDITOR start */
    
    .labcell.label,
    .labcell.timestamp { vertical-align:baseline; }
    
    .labcell.date,
    .labcell.radiogroup { vertical-align:bottom; }
    
    .labcell.checkbox,
    .labcell.checkgroup,
    .labcell.time,
    .labcell.filtered_selector,
    .labcell.selector,
    .labcell.richtext,
    .labcell.textfield,
    .labcell.textarea { vertical-align:top; padding-top:4px; }
    
    .labcell.richtext { white-space:nowrap; overflow:visible;}
    
    /* labels */
    LABEL.type-checkgroup {display:block;}
    LABEL.type-radiogroup { white-space:nowrap; }
    
    /* red asterisk in labels */
    LABEL.infolabel:after { padding-left:1px; color:transparent; content:'*'}
    LABEL.infolabel.required:after { color:red; }
    LABEL.infolabel.is-error { background-color:yellow; border-radius:3px; padding:1px 3px; }
    
    /* affored to display response by updating m:n-relations with AJAX call jsUpdateFromArray() in Partial/Editor/Optionsgroup.html */
    .response {height:1em;font-size:smaller;}
    
    /* input element width */
    .type-textfield {width:170px;}
    .type-textarea {width:170px;}
    .type-date {width:88px;}
    .type-time {width:70px;}
    SELECT.type-selector {width:170px;}
    SELECT.type-filtered_selector {width:170px;}
    INPUT.type-filtered_selector[type="text"] {width:48px;}

    /* upload elements */
    INPUT.type-upload { width:170px; white-space:normal; overflow:visible; }
    DIV.type-upload {display:none;}
    DIV.file_buttonbox {float:right;width:auto;}
    
    .file_button {text-align:center;border-radius: 4px;box-shadow:0 0 8px #009ee9;cursor:pointer;}
    .file_button.delete {padding:0 3px;}
    .file_button.add_record:before {padding:0 0 0 2px;}
    
    /* EDITOR end*/
    
    .clearleft {
		clear:left;
    }
    .clearright {
		clear:right;
    }
    .clearer {
		clear:both;
    }
    
    /* DISPLAY as page - PAGER */
    
    .skala-container  {
		line-height:25px;
    }
    
    .page-container .jslink, .skala-container span  {
		cursor:pointer;
		background: #009ee0;
		padding:2px 6px;
		border:thin solid #009ee0;
		border-radius:100%;
		color:white;font-weight:normal;
    }
    
    .page-container .jslink.sel, .skala-container span.visible { color:black; }
    .page-container .jslink.sel { font-weight:bold; }
	.page-container .jslink:hover {color:#efefef;opacity:0.7}
	.page-container .jslink.sel:hover .skala-container span.visible:hover {color:#000;}
    
    DIV.pager-page.visible {display:block;}
    DIV.pager-page.invisible {display:none;}
    span.pager-skala {margin:0 2px;white-space:nowrap;overflow:visible;}
    
    /* Tables with divs */
    .tTable        { display: table; }
    .tTableRow     { display: table-row; }
    .tTableHeadRow { display: table-header-group; }
    .tTableBody    { display: table-row-group; }
    .tTableFootRow { display: table-footer-group; }
    .tTD, .tTH     { display: table-cell; }
    
    .grid_content DIV .tx-sdb-adminer DIV.tTable, .grid_content DIV .tx-sdb-adminer DIV.tTableRow, .grid_content DIV .tx-sdb-adminer DIV.tTableBody {
        padding:0;
    }

    .tTable DIV.file_buttonbox {display: table-cell; text-align:right;width:100%;float:none;}
    .tTable INPUT.type-filtered_selector[type="text"] {width:85px;}
	
	.tTable { margin-bottom:7px; }
	
    .tColor-even { background-color: #fff; }
    .tColor-odd { background-color: #fff; }

    .tTableHeadRow, .tTableFootRow {
            background-color: #ddd;
            font-weight: bold;
    }
    
    .tTD, .tTH {
            border: 1px solid #999999;
            width:auto;
            height:100%;
            /* white-space:nowrap; */
            overflow: visible;
            padding: 3px;
    }
    .tTH {
            background-color: #afe080;
            padding-right:10px;
    }
    
    .tTable DIV.clearright {
        clear:both;
    }
    .tTable .tTableRow.contenttype-selector .tTH LABEL.infolabel , .tTable .tTableRow.contenttype-filtered_selector.tTH LABEL.infolabel , .tTable DIV.file_buttonbox {
        display: table-cell;
    }
    
    
    @media screen and (max-width:641px) {
        .tTable, .tTableHeadRow, .tTableBody, .tTableFootRow, .tTableRow, .tTD, .tTH {
            display: block;
        }
        .tTD, .tTH {
            width: 100%; border:0;
        }
        .tTable { margin-bottom:0px; }
        DIV.tTableRow {  margin-bottom: 7px ;  border: 2px solid #999;border-radius:3px;}
        .tColor-even .tTH, .tColor-even .tTD { background-color: #c0f0a0; }
        .tColor-odd .tTH, .tColor-odd .tTD { background-color: #c0f0a0; }
    }
    
    
	.tx-sdb-adminer .widget:hover {
		box-shadow: 0 0 10px #00BDFF;
		border-radius: 4px;
	}
	
    INPUT.listEditInput {width:200px;}
    DIV.indexfield INPUT.listEditInput {width:40px;}
    
    TABLE.listEditTable { width:auto; }
    TABLE.listEditTable TD { vertical-align:middle;white-space:nowrap;overflow:visible; }
)
