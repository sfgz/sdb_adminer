<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints',
        'label' => 'dbname',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
            'disabled' => 'hidden',
        ],
		'searchFields' => 'dbname,server,port,username',
        'iconfile' => 'EXT:sdb_adminer/Resources/Public/Icons/tx_sdbadminer_domain_model_accesspoints.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'hidden,dbname, server, port, username, pass',
    ],
    'types' => [
		'1' => ['showitem' => 'hidden,dbname, server, port, username, pass'],
    ],
    'columns' => [
		'hidden' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.hidden'
                    ]
                ],
            ],
        ],
	    'dbname' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.dbname',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'server' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.server',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'port' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.port',
	        'config' => [
			    'type' => 'input',
			    'size' => 4,
			    'eval' => 'trim',
			    'default' => '3306'
			],
	    ],
	    'username' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.username',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'pass' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang_db.xlf:tx_sdbadminer_domain_model_accesspoints.pass',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'password'
			],
	    ],
    ],
];
