<?php
/***************************************************************
*  Copyright notice
*
*  (c) 2007-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Hooks for the 'sdb_adminer' extension
 *
 * @author		Daniel Rueegg, Francois Suter (Cobweb)
 * @package		TYPO3
 * @subpackage	tx_sdbadminer
 */
class tx_sdbadminer_hooks implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * extConf
	 *
	 * @var array
	 */
	protected $extConf;

	/**
	 * __construct
	 */
	public function __construct() {
	}

	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 *
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function processResponse($data, $pObj) {
		// get data in form of an array instead of an object
		$rawData = $data;
		$id=0;
		foreach($rawData as $locRow){
		    ++$id;
		    $locArr[$id]=$locRow;
		    $locArr[$id]['Email'] = isset($locRow['Email']) && !empty($locRow['Email']) ? $locRow['Email'] : $this->nameToUsername( $locRow['MVorname'] ) . '.' . $this->nameToUsername( $locRow['MName'] ) . '@arbastrom.ch';
		    $locArr[$id]['Username'] = trim( $this->nameToUsername( $locRow['MVorname'] ) . '.' . $this->nameToUsername( $locRow['MName'] ) ,  '.' );
		    $locArr[$id]['Name'] =  trim( $locRow['MVorname'] . ' ' . $locRow['MName'] );
		}
		return  $locArr ;
	}

	/**
	 * returns the incomed value in lowercase with transformed umlauds
	 *
	 * @param string $name
	 * @return string
	 */
	protected function nameToUsername( $name ) {
            $s = [ 'ä'=>'ae' , 'ö'=>'oe' , 'ü'=>'ue' ];
            $email = str_replace( array_keys($s) , $s , strtolower($name) );
            return $email;
	}
}
?>
