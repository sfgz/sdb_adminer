//private calendar controller IIFE
var pureJSCalendar = (function () {
    let wrap, label, calYear, calMonth, calDateFormat, firstDay, isIE11;

    isIE11 = !!window.MSInputMethodContext && !!document.documentMode;

    //check global variables for calendar widget and set default localization values
    if (window.months === undefined) {
        window.months = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'July', 'August', 'September', 'Oktober', 'November', 'Dezember'];
    }

    if (window.shortDays === undefined) {
        window.shortDays = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
    }

    //first day of week combinations array
    const firstDayCombinations = [
        [0, 1, 2, 3, 4, 5, 6],
        [1, 2, 3, 4, 5, 6, 0],
        [2, 3, 4, 5, 6, 0, 1],
        [3, 4, 5, 6, 0, 1, 2],
        [4, 5, 6, 0, 1, 2, 3],
        [5, 6, 0, 1, 2, 3, 4],
        [6, 0, 1, 2, 3, 4, 5]
    ]

    //DOM strings helper
    const DOMstrings = {
        divCal: 'cal',
        monthLabel: 'label',
        btnPrev: 'prev',
        btnNext: 'next',
        sunLabel: 'eformSun',
        monLabel: 'eformMon',
        tueLabel: 'eformTue',
        wedLabel: 'eformWed',
        thuLabel: 'eformThu',
        friLabel: 'eformFri',
        satLabel: 'eformSat',
        tdDay: '.eformDay'
    }

    //open function changed by dani.rueegg
    function open( element , pastDays, futureDays ) {
        var dateFormat = 'dd.MM.yyyy';
        var firstDayOfWeek = 1;
        var zindex = 98;
        var obj = document.getElementById( element );
        var x = obj.offsetLeft -  20;
        var y = obj.offsetTop + obj.offsetHeight;
        var minDate = new Date();
        minDate.setDate(minDate.getDate() - pastDays);
        var minDateString = minDate.toISOString().split('T')[0]; // "2016-06-08"
        var maxDate = new Date();
        maxDate.setDate(maxDate.getDate() + futureDays );
        var maxDateString = maxDate.toISOString().split('T')[0]; // "2016-06-08"
        return openAtPos(dateFormat, x, y, firstDayOfWeek, minDateString , maxDateString , element, zindex)
    }

    //open function renamed from open() to openAtPos() by dani.rueegg
    function openAtPos( dateFormat, x, y, firstDayOfWeek, minDate, maxDate, element, zindex ) {
        //prevent to open more than one calendar
        if (document.getElementById( DOMstrings.divCal )) {
            close();
            return false;
        }
        //init def props
        eFormMinimalDate = DateParse(minDate);
        eFormMaximalDate = DateParse(maxDate);
        eFormCalendarElement = element;
        firstDay = firstDayOfWeek;

        //set default first date of week
        if (firstDayOfWeek === undefined) {
            firstDayOfWeek = 6;
        } else {
            firstDayOfWeek -= 1;
        }

        //create html and push it into DOM
        const newHtml = '<div id="' + DOMstrings.divCal + '" style="top:' + y + 'px;left:' + x + 'px;z-index:' + zindex + ';"><div class="header"><span class="left button" id="prev"> &lang; </span><span class="left hook"></span><span class="month-year" id="label"> June 20&0 </span><span class="right hook"></span><span class="right button" id="next"> &rang; </span></div ><table id="days"><tr><td id="eformSun">sun</td><td id="eformMon">mon</td><td id="eformTue">tue</td><td id="eformWed">wed</td><td id="eformThu">thu</td><td id="eformFri">fri</td><td id="eformSat">sat</td></tr></table><div id="cal-frame"><table class="curr"><tbody></tbody></table></div></div >'
        document.getElementById(element).insertAdjacentHTML('afterend', newHtml);
//         removed by dani.rueegg
//         document.getElementsByTagName('body')[0].insertAdjacentHTML('beforeend', newHtml);

        calDateFormat = dateFormat;
        wrap = document.getElementById(DOMstrings.divCal);
        label = document.getElementById(DOMstrings.monthLabel);

        //register events
        document.getElementById(DOMstrings.btnPrev).addEventListener('click', function () { switchMonth(false); });
        document.getElementById(DOMstrings.btnNext).addEventListener('click', function () { switchMonth(true); });
        // added by daniel.rueegg move calendar to the given date
        // removed: label.addEventListener('click', function () { switchMonth(null, new Date().getMonth() , new Date().getFullYear()); });
        var datevalue = document.getElementById(element).value ;
        if( datevalue ){ 
            var splitedDate = datevalue.split('.');
            label.addEventListener('click', function () { switchMonth(null, splitedDate[1]-1 , splitedDate[2]); }); 
        }else{
            label.addEventListener('click', function () { switchMonth(null, new Date().getMonth() , new Date().getFullYear()); });
        }

        //shorter day version labels
        const dayCombination = firstDayCombinations[firstDayOfWeek];

        document.getElementById(DOMstrings.sunLabel).textContent = window.shortDays[dayCombination[0]];
        document.getElementById(DOMstrings.monLabel).textContent = window.shortDays[dayCombination[1]];
        document.getElementById(DOMstrings.tueLabel).textContent = window.shortDays[dayCombination[2]];
        document.getElementById(DOMstrings.wedLabel).textContent = window.shortDays[dayCombination[3]];
        document.getElementById(DOMstrings.thuLabel).textContent = window.shortDays[dayCombination[4]];
        document.getElementById(DOMstrings.friLabel).textContent = window.shortDays[dayCombination[5]];
        document.getElementById(DOMstrings.satLabel).textContent = window.shortDays[dayCombination[6]];

        //fire inicialization event trigger
        label.click();
    }

    //switches current month
    function switchMonth(next, month, year) {
        var curr = label.textContent.trim().split(' '), calendar, tempYear = parseInt(curr[1], 10);
        if (month === undefined) {
            month = ((next) ? ((curr[0] === window.months[11]) ? 0 : months.indexOf(curr[0]) + 1) : ((curr[0] === window.months[0]) ? 11 : months.indexOf(curr[0]) - 1));
        }
        
        if (!year) {
            if (next && month === 0) {
                year = tempYear + 1;
            } else if (!next && month === 11) {
                year = tempYear - 1;
            } else {
                year = tempYear;
            }
        }

        //set month and year for widget scope
        calMonth = month + 1;
        calYear = year;

        calendar = createCal(year, month);

        var curr = document.querySelector('.curr')
        curr.innerHTML = '';
        curr.appendChild(calendar.calendar());

        //disable days below minimal date
        if (eFormMinimalDate !== undefined) {
            if (year < eFormMinimalDate.year || ( year <= eFormMinimalDate.year && month <= eFormMinimalDate.month ) ) {
            // only past years (and all months and days) OR this year AND past Months (and all days) OR this Month and past days
                const emptyCount = document.querySelector('.curr table').rows[0].querySelectorAll('td:empty').length;
                const tdDisabled = document.querySelectorAll('.eformDay');
                for (var i = 0; i < tdDisabled.length; ++i) {
                      //// removed by daniel.rueegg if (i - emptyCount + 1 < eFormMinimalDate.day || month < eFormMinimalDate.month || year < eFormMinimalDate.year) {
                      // FIXED: if we are on 10.4.2019 and min is set to 31.3.2019
                      // DAY 10 < 31 but 4 > 3!
                      // if we are on 10.4.2019 and min is set to 31.5.2018
                      // MONTH 4 < 5 but 2019 > 2018!
                    var loopDate = ( 10000 * parseInt(year) ) + ( 100 * parseInt(month) ) + parseInt( i - emptyCount + 1 );
                    var minDate =  ( 10000 * parseInt(eFormMinimalDate.year) ) + ( 100 * parseInt(eFormMinimalDate.month) ) + parseInt( eFormMinimalDate.day );
                    if ( loopDate < minDate ) {
                        tdDisabled[i].classList.add('eformDayDisabled');
                        tdDisabled[i].onclick = function () {
                            return false;
                        }
                    }
                }
            }
        }

        //disable days above maximal date
        if (eFormMaximalDate !== undefined) {
            if (year > eFormMaximalDate.year || ( year >= eFormMaximalDate.year && month >= eFormMaximalDate.month ) ) {
            // only future years (and all months and days) OR this year AND future Months (and all days) OR this Month and future days
                const emptyCount = document.querySelector('.curr table').rows[0].querySelectorAll('td:empty').length;
                const tdDisabled = document.querySelectorAll('.eformDay');
                for (var i = 0; i < tdDisabled.length; ++i) {
                    var loopDate = ( 10000 * parseInt(year) ) + ( 100 * parseInt(month) ) + parseInt( i - emptyCount + 1 );
                    var maxDate =  ( 10000 * parseInt(eFormMaximalDate.year) ) + ( 100 * parseInt(eFormMaximalDate.month) ) + parseInt( eFormMaximalDate.day );
                    if ( loopDate > maxDate ) {
                        tdDisabled[i].classList.add('eformDayDisabled');
                        tdDisabled[i].onclick = function () {
                            return false;
                        }
                    }
                    
                }
            }
        }

        label.textContent = calendar.label;
    }

    //main calendar function. Creates calendar itself and stores into cache
    function createCal(year, month) {
        var day = 1, i, j, haveDays = true,
            startDay = new Date(year, month, day).getDay(),
            daysInMonths = [31, (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            calendar = [];

        startDay -= firstDay;
        if (startDay < 0) {
            startDay = 7 + startDay;
        }

        if (createCal.cache[year] && !isIE11) {
            if (createCal.cache[year][month]) {
                return createCal.cache[year][month];
            }
        } else {
            createCal.cache[year] = {};
        }

        i = 0;
        while (haveDays) {
            calendar[i] = [];
            for (j = 0; j < 7; j++) {
                if (i === 0) {
                    if (j === startDay) {
                        calendar[i][j] = day++;
                        startDay++;
                    }
                } else if (day <= daysInMonths[month]) {
                    calendar[i][j] = day++;
                } else {
                    calendar[i][j] = '';
                    haveDays = false;
                }
                if (day > daysInMonths[month]) {
                    haveDays = false;
                }
            }
            i++;
        }

        ////6th week of month fix IF NEEDED
        //if (calendar[5]) {
        //    for (i = 0; i < calendar[5].length; i++) {
        //        if (calendar[5][i] !== '') {
        //            calendar[4][i] = '<span>' + calendar[4][i] + '</span><span>' + calendar[5][i] + '</span>';
        //        }
        //    }
        //    calendar = calendar.slice(0, 5);
        //}

        for (i = 0; i < calendar.length; i++) {
            calendar[i] = '<tr><td class="eformDay" onclick="pureJSCalendar.dayClick(this)">' + calendar[i].join('</td><td class="eformDay" onclick="pureJSCalendar.dayClick(this)">') + '</td></tr>';
        }        

        const calendarInnerHtml = calendar.join('');
        calendar = document.createElement('table', { class: 'curr' });
        calendar.innerHTML = calendarInnerHtml;
        const tdEmty = calendar.querySelectorAll('td:empty');
        for (var i = 0; i < tdEmty.length; ++i) {
            tdEmty[i].classList.add('nil');
        }
        var nowDateObj = new Date(); 
        var nowMonth = nowDateObj.getMonth() ; 
        var nowDay = nowDateObj.getDate().toString() ; 
        var datevalue = document.getElementById(eFormCalendarElement).value ;
        if( datevalue ){ 
            var splitedDate = datevalue.split('.');
            var selMonth = splitedDate[1]-1 ; 
            var selDay = splitedDate[0] ; 
        }else{
            var selMonth = nowMonth ; 
            var selDay = nowDay ; 
        }
        if ( month === selMonth || month === nowMonth ) {
            const calTd = calendar.querySelectorAll('td');
            const calTdArray = Array.prototype.slice.call(calTd); 
            calTdArray.forEach(function (current, index, array) {
                if ( parseInt(current.innerHTML) === parseInt(selDay) &&  parseInt(month) === parseInt(selMonth) ) {
                    current.classList.add('selday');
                }
                if ( parseInt(current.innerHTML) === parseInt(nowDay) && parseInt(month) === parseInt(nowMonth) ) {
                    current.classList.add('today');
                }
            });
        }

        createCal.cache[year][month] = { calendar: function () { return calendar }, label: months[month] + ' ' + year };//calendar.clone()

        return createCal.cache[year][month];
    }
    createCal.cache = {};

    //day click event function => than close
    const dayClick = function (element) {
        const dateResult = DateToString(new Date(calYear, calMonth-1, parseInt(element.innerHTML)), calDateFormat);
        document.getElementById(eFormCalendarElement).value = dateResult;
        close();
    }

    // join
    function joinObj(obj, seperator) {
        var out = [];
        for (k in obj) {
            out.push(k);
        }
        return out.join(seperator);
    }

    //returns string in desired format
    function DateToString(inDate, formatString) {
        var dateObject = {
            M: inDate.getMonth() + 1,
            d: inDate.getDate(),
            D: inDate.getDate(),
            h: inDate.getHours(),
            m: inDate.getMinutes(),
            s: inDate.getSeconds(),
            y: inDate.getFullYear(),
            Y: inDate.getFullYear()
        };
        // Build Regex Dynamically based on the list above.
        // Should end up with something like this "/([Yy]+|M+|[Dd]+|h+|m+|s+)/g"
        var dateMatchRegex = joinObj(dateObject, "+|") + "+";
        var regEx = new RegExp(dateMatchRegex, "g");
        formatString = formatString.replace(regEx, function (formatToken) {
            var datePartValue = dateObject[formatToken.slice(-1)];
            var tokenLength = formatToken.length;
            
            if (formatToken === 'MMMM') {
                return window.months[dateObject.M - 1];
            }

            // A conflict exists between specifying 'd' for no zero pad -> expand to '10' and specifying yy for just two year digits '01' instead of '2001'.  One expands, the other contracts.
            // so Constrict Years but Expand All Else
            if (formatToken.indexOf('y') < 0 && formatToken.indexOf('Y') < 0) {
                // Expand single digit format token 'd' to multi digit value '10' when needed
                var tokenLength = Math.max(formatToken.length, datePartValue.toString().length);
            }
            var zeroPad;
            try {
                zeroPad = (datePartValue.toString().length < formatToken.length ? "0".repeat(tokenLength) : "");
            } catch (ex) {//IE11 repeat catched
                zeroPad = (datePartValue.toString().length < formatToken.length ? repeatStringNumTimes("0", tokenLength) : "");
            }
            return (zeroPad + datePartValue).slice(-tokenLength);
        });

        return formatString;
    }
    Date.prototype.ToString = function (formatStr) { return DateToString(this.toDateString(), formatStr); }

    //IE11 repeat alternative
    function repeatStringNumTimes(string, times) {
        var repeatedString = "";
        while (times > 0) {
            repeatedString += string;
            times--;
        }
        return repeatedString;
    }

    //close event function (fadeout)
    function close() {
        // added by dani.rueegg
        // remove date restriction
        const tdDisabled = document.querySelectorAll('.eformDay.eformDayDisabled');
        for (var i = 0; i < tdDisabled.length; ++i) {
                tdDisabled[i].onclick = function () {
                    pureJSCalendar.dayClick( this );
                };
                tdDisabled[i].classList.remove('eformDayDisabled');
        }
//         createCal.cache = {};
        // end added by dani.rueegg
        fadeOutEffect( '#' + DOMstrings.divCal , remove);
    }

    //remove calendar box
    var remove = function () {
        try {
            document.getElementById(DOMstrings.divCal).remove();
        } catch (ex) {//ie11 fix
            const child = document.getElementById(DOMstrings.divCal);
            child.parentNode.removeChild(child);
        }
    }

    //parse date
    function DateParse(date) {
        let parsedDate, newDate;
        const currentDate = date;
        
        if (currentDate != null) {
            splitedDate = currentDate.split('-');
            newDate = { year: splitedDate[0], month: parseInt(splitedDate[1]-1), day: splitedDate[2] };
        }

        return newDate;
    }

    //function accesibility
    return {
        open: open,
        switchMonth: switchMonth,
        createCal: createCal,
        dayClick: dayClick,
        close: close
    };
})();

// initiate function added by dani.rueegg
// prepend the calendar icon with open-event binded onClick 
function registerCalendarField( element , pastDays, futureDays ) {
        const newHtml = '<span class="calicon" id="icon_' + element + '" onClick="pureJSCalendar.open( \'' + element + '\' , ' + pastDays + ' , ' + futureDays + ' );"></span>';
        document.getElementById(element).classList.add("calinput");
        document.getElementById(element).insertAdjacentHTML('beforebegin', newHtml);
}

//plain javascript fadeout alternative
function fadeOutEffect(selector, callback) {
    var fadeTarget = document.querySelector(selector);
    if (fadeTarget != null) {
        var fadeEffect = setInterval(function () {
            if (!fadeTarget.style.opacity) {
                fadeTarget.style.opacity = 1;
            }
            if (fadeTarget.style.opacity > 0) {
                fadeTarget.style.opacity -= 0.1;
            } else {
                clearInterval(fadeEffect);
                callback();
            }
        }, 20);
    }
}
