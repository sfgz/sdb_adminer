#
# Table structure for table 'tx_sdbadminer_domain_model_accesspoints'
#
CREATE TABLE tx_sdbadminer_domain_model_accesspoints (

	uid int(10) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	server varchar(255) DEFAULT '' NOT NULL,
	port varchar(255) DEFAULT '3306' NOT NULL,
	username varchar(255) DEFAULT '' NOT NULL,
	pass varchar(255) DEFAULT '' NOT NULL,
	dbname varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid)

);
