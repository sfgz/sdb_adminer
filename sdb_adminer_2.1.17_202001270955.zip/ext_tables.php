<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SdbAdminer',
            'Main',
            'DB Adminer Ausgabe'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SdbAdminer',
            'Edit',
            'DB Adminer Editor'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SdbAdminer',
            'Edlist',
            'DB Adminer List-Editor'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sdb_adminer', 'Configuration/TypoScript', 'DB Adminer');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sdbadminer_domain_model_accesspoints', 'EXT:sdb_adminer/Resources/Private/Language/locallang_csh_tx_sdbadminer_domain_model_accesspoints.xlf');

    }
);

if (TYPO3_MODE === 'BE') {
		// include this for usage of dynamic flexforms AND to generate db-list to Add BE User setting [on line 42] by getOptionlistDbNames()
		include_once(\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY).'class.tx_sdbadminer_addFieldsToFlexForm.php');

		// load plugin main (filter-controller to display recordsets in fe) AND disable pages-chooser in this content-element
		$TCA['tt_content']['types']['list']['subtypes_addlist']['sdbadminer_main'] = 'pi_flexform';
		\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('sdbadminer_main', 'FILE:EXT:sdb_adminer/Configuration/Flexforms/sdbadminer_main.xml');
		$TCA['tt_content']['types']['list']['subtypes_excludelist']['sdbadminer_main']='pages';

		// load plugin edit (edit-controller to edit recordsets in a form in fe) AND disable pages-chooser in this content-element
		$TCA['tt_content']['types']['list']['subtypes_addlist']['sdbadminer_edit'] = 'pi_flexform';
		\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('sdbadminer_edit', 'FILE:EXT:sdb_adminer/Configuration/Flexforms/sdbadminer_edit.xml');
		$TCA['tt_content']['types']['list']['subtypes_excludelist']['sdbadminer_edit']='pages';

		// load plugin edlist (editlist-controller to edit recordsets in a list in fe) AND disable pages-chooser in this content-element
		$TCA['tt_content']['types']['list']['subtypes_addlist']['sdbadminer_edlist'] = 'pi_flexform';
		\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('sdbadminer_edlist', 'FILE:EXT:sdb_adminer/Configuration/Flexforms/sdbadminer_edlist.xml');
		$TCA['tt_content']['types']['list']['subtypes_excludelist']['sdbadminer_edlist']='pages';

		// Add BE User setting: let user choose a database
		$GLOBALS['TYPO3_USER_SETTINGS']['columns']['sdb_adminer'] = [
			'label' => 'LLL:EXT:sdb_adminer/Resources/Private/Language/locallang.xlf:settings.field.sdb_adminer',
			'type' => 'select',  
			'items' => \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tx_sdbadminer_addFieldsToFlexForm')->getOptionlistDbNames()
		];
        // add field to be_user settings
		\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToUserSettings(
			'sdb_adminer',
			'after:startModule'
		);

}

/*
### import users with extension svconnector_sql
// set sort order
$GLOBALS['TCA']['fe_users']['ctrl']['default_sortby'] = 'ORDER BY uid';

// Add the external information to the ctrl section
$GLOBALS['TCA']['fe_users']['ctrl']['external'] = [
	0 => [
		'connector' => 'sql',
		'parameters' => [
			'driver' => 'mysqli',
			'server' => '127.0.0.1',
			'user' => 'wirker_arba',
			'password' => '4r845tr0m',
			'database' => 'wirker_arba_import',
			'query' => 'SELECT * FROM Mitarbeiter WHERE AlteMitarbeiter = 0',
			'init' => 'SET NAMES utf8',
			'fetchMode' => '2'
		],
		'data' => 'array',
		'referenceUid' => 'company',
		'enforcePid' => TRUE,
		'priority' => 410,
		'disabledOperations' => 'delete',
		'description' => 'Importiert Mitarbeiter'
	]
];

// fix values
$GLOBALS['TCA']['fe_users']['columns']['password']['external'] = array(
	0 => array(
		'transformations' => [
            10 => ['value' => 'X5.$3zVo0+a']
		],
		'disabledOperations' => 'update'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['usergroup']['external'] = array(
	0 => array(
		'transformations' => [
            10 => ['value' => '1']
		],
		'disabledOperations' => 'update'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['tx_extbase_type']['external'] = array(
	0 => array(
		'transformations' => [
            10 => ['value' => 'Tx_Extbase_Domain_Model_FrontendUser']
		],
		'disabledOperations' => 'update'
	)
);

// from script
$GLOBALS['TCA']['fe_users']['columns']['username']['external'] = array(
	0 => array(
		'field' => 'Username',
		'disabledOperations' => 'update'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['name']['external'] = array(
	0 => array(
		'field' => 'Name',
		'disabledOperations' => 'update'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['email']['external'] = array(
	0 => array(
		'field' => 'Email',
		'disabledOperations' => 'update'
	)
);
// from db MitarbeiterID
$GLOBALS['TCA']['fe_users']['columns']['company']['external'] = array(
	0 => array(
		'field' => 'MitarbeiterID',
		'disabledOperations' => 'update'
	)
);
// from db MVorname
$GLOBALS['TCA']['fe_users']['columns']['first_name']['external'] = array(
	0 => array(
		'field' => 'MVorname',
		'disabledOperations' => 'update'
	)
);
// from db MName
$GLOBALS['TCA']['fe_users']['columns']['last_name']['external'] = array(
	0 => array(
		'field' => 'MName',
		'disabledOperations' => 'update'
	)
);
*/
