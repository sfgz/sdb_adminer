<?

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Utility\PathUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

class tx_sdbadminer_addFieldsToFlexForm {

    public function __construct()
    {
		$this->sqlUtility = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
		$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
	}

	/**
	 * getOptionlistDbNames
	 * 
	 * flexform BE-User settings
	 * used in ext_tables.php  to extend TYPO3_USER_SETTINGS with db-list
	 * 
	 * hide record if be-user has no right to edit
	 * 
	 * @return array 
	 */
	Public function getOptionlistDbNames()
	{
		$this->sqlUtility->connectToDatabase('');
		$aDatabases = $this->sqlUtility->readDatabases();

		if( !is_array($aDatabases) ) $aDatabases = [];
		// put empty value on first place
		array_unshift( $aDatabases ,  'wählen...' );
		return $aDatabases;
	}
  
	/**
	 * addOptions_dbnames
	 * 
	 * flexform Adminer-plugin itemsProcFunc 
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_dbnames($config)
	{
		$this->sqlUtility->connectToDatabase('');
		$aDatabases = $this->sqlUtility->readDatabases();
		// remove information_schmema
		if( isset($aDatabases['information_schema']) ) unset($aDatabases['information_schema']);
		
		// get users default dbname
		$dbname = $this->sqlUtility->getBeUsersDB();
		$config = $this->addOptions( $aDatabases , $config );
		
		// put users default dbname on first place
		if( isset( $config['items'][$dbname] ) ) unset($config['items'][$dbname]);
		if( is_array($config['items']) ) array_unshift( $config['items'] , [ $dbname , $dbname ] );
		return $config;
	}

	/**
	 * addOptions_tablenames_viewnames
	 * flexform Adminer-plugin itemsProcFunc 
	 * addOptions_tables_views includes views
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_tablenames_viewnames($config) 
	{
		$dbname = is_array($config['row']['settings.dbname']) ? $config['row']['settings.dbname'][0] : $config['row']['settings.dbname'];
		if( empty($dbname) ) $dbname = $this->sqlUtility->getBeUsersDB();
		$this->sqlUtility->connectToDatabase( $dbname );
		$this->sqlUtility->readTabels( $dbname );
 		$aTables = $this->sqlUtility->info['tables'];
		$config = $this->addOptions( $aTables , $config );
		return $config;
	}
  
	/**
	 * addOptions_tablenames_only
	 * flexform Adminer-plugin itemsProcFunc 
	 * addOptions_tables without views
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_tablenames_only($config) 
	{
		$dbname = is_array($config['row']['settings.dbname']) ? $config['row']['settings.dbname'][0] : $config['row']['settings.dbname'];
		// fallback
		if( empty($dbname) ) $dbname = $this->sqlUtility->getBeUsersDB();
		// decide wich type of tables to list (usual table or m:n subtable)
		$formtype = is_array($config['row']['settings.formtype']) ? $config['row']['settings.formtype'][0] : $config['row']['settings.formtype'];
		
		$this->sqlUtility->connectToDatabase( $dbname );
		if( $formtype == 2 ) $this->sqlUtility->readMnTabels( $dbname );
 		$aTables = $this->sqlUtility->info['tables'];
 		
		$config = $this->addOptions( $aTables , $config );
		return $config;
	}
  
	/**
	 * addOptions_fieldnames_ifnot_mn_table
	 * flexform Adminer-plugin itemsProcFunc 
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_fieldnames_ifnot_mn_table($config) 
	{
		$allPiSettings = $this->flexdataUtility->getFlexformData( $config['row']['uid'] );
		
		if( $allPiSettings['formtype'] == 2 ) {
			$config['items'][0] = [ 0 => 'Option bei m:n Tabellen deaktiviert' , 1 => 0 ] ;
			return $config;
		}
		$config = $this->getFieldnames( $config , true ) ;
	}
  
	/**
	 * addOptions_fieldnames_separe_primary
	 * flexform Adminer-plugin itemsProcFunc 
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_fieldnames_choosen($config) 
	{
		$allPiSettings = $this->flexdataUtility->getFlexformData( $config['row']['uid'] );
		$aEditfields = explode( ',' , $allPiSettings['editfields'] );
		
		if( is_array($aEditfields) ){
			$config = $this->addOptions( $aEditfields , $config );
		}
		return $config;
	}
  
	/**
	 * addOptions_fieldnames_separe_primary
	 * flexform Adminer-plugin itemsProcFunc 
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_fieldnames_separe_primary($config) 
	{
		return $this->getFieldnames($config , true ) ;
	}
  
	/**
	 * flexform Adminer-plugin itemsProcFunc 
	 * addOptions_fieldnames
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_fieldnames_include_primary($config) 
	{
		$config = $this->getFieldnames($config , false ) ;
		return $config;
	}
  
	/**
	 * addOptions_opposite_fieldnames
	 * flexform Adminer-plugin itemsProcFunc 
	 * 
	 * @param array $config
	 * @return array 
	 */
	Public function addOptions_opposite_fieldnames($config) 
	{
		$dbname = is_array($config['row']['settings.dbname']) ? $config['row']['settings.dbname'][0] : $config['row']['settings.dbname'];
		if( empty($dbname) ) $dbname = $this->sqlUtility->getBeUsersDB();
		$this->sqlUtility->connectToDatabase( $dbname );
		$tablename = is_array($config['row']['settings.oppositetable']) ? $config['row']['settings.oppositetable'][0] : $config['row']['settings.oppositetable'];
		$this->sqlUtility->readFieldnamesIncludePrimary( $dbname , $tablename );
		$aFieldnames = $this->sqlUtility->info['fields'];
		$config = $this->addOptions( $aFieldnames , $config );
		return $config;
	}
  
	/**
	 * addOptions
	 * Helper for all addOptions_ procs
	 * 
	 * @param array $aContent
	 * @param array $config
	 * @return array 
	 */
	Private function addOptions( $aContent , $config ) 
	{
		$optionList = array();
		$optionList[] = array(0 => '(manuell)' , 1 =>  '' );
		if( !is_array($aContent) || !count($aContent) ) return $optionList;
		
		$optionList = array();
		// add first option
		foreach( $aContent as $cont ){
			$optionList[lcfirst($cont)] = array(0 =>  $cont, 1 =>  $cont );
		}
 		$config['items'] = array_merge($config['items'],$optionList);
		return $config;
	}
  
	/**
	 * getFieldnames
	 * Helper for specific addOptions_ proc
	 * 
	 * @param array $config
	 * @param boolean $withoutPrimary optional
	 * @return array 
	 */
	Public function getFieldnames($config , $withoutPrimary = false ) 
	{
		if( !isset($config['row']['settings.dbname']) || !isset($config['row']['settings.tablename']) ){
			$piNr = $config['row']['uid'];
			$allPiSettings = $this->flexdataUtility->getFlexformData( $piNr );
			if( !isset($config['row']['settings.dbname']) ) $config['row']['settings.dbname'] = $allPiSettings['dbname'];
			if( !isset($config['row']['settings.tablename']) ) $config['row']['settings.tablename'] = $allPiSettings['tablename'];
		}
		$dbname = is_array($config['row']['settings.dbname']) ? $config['row']['settings.dbname'][0] : $config['row']['settings.dbname'];
		if( empty($dbname) ) $dbname = $this->sqlUtility->getBeUsersDB();
		$this->sqlUtility->connectToDatabase( $dbname );
		$tablename = is_array($config['row']['settings.tablename']) ? $config['row']['settings.tablename'][0] : $config['row']['settings.tablename'];
		if( $withoutPrimary ){
			$this->sqlUtility->readFieldnamesSeparePrimary( $dbname , $tablename );
		}else{
			$this->sqlUtility->readFieldnamesIncludePrimary( $dbname , $tablename );
		}
		$aFieldnames = $this->sqlUtility->info['fields'];
		$config = $this->addOptions( $aFieldnames , $config );
		return $config;
	}
  
}
