<?php
namespace Sfgz\SdbAdminer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class RestrictionsUtility
 * 
 */

/*
 * 
 * Translate a condition containig the fieldvaue of _Datum_ and date intervals
 * _Datum_ > CURRENT_DATE - INTERVAL 30 DAY AND _Datum_ < CURRENT_DATE + INTERVAL 5 DAY
 * to
 * SELECT ('2019-05-05' > CURRENT_DATE - INTERVAL 30 DAY AND '2019-05-05' < CURRENT_DATE + INTERVAL 5 DAY ) AS OK;
 * 
 * Translate a condition containig the fieldvaue of _ProjektID_ and joins
 * _ProjektID_:ProjektID.Projekte.Abgeschlossen = 0 OR _ProjektID_:ProjektID.Projekte.Abgeschlossen IS NULL 
 * to
 * SELECT COUNT(Abgeschlossen) AS OK FROM Projekte WHERE ProjektID = 7 AND ( Abgeschlossen = 0  OR Abgeschlossen IS NULL )
 * 
 * 
*/

class RestrictionsUtility {

	/**
	* @var int
	*/
	Private $actionContext = 4;

	/**
	* @var array
	*/
	Private $settings = array();

	/**
	* @var array
	*/
	Private $aRecordset = array();

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    Private $flexdataUtility = null;

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    Private $sqlUtility = null;

    /**
     * convertDataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\ConvertDataUtility
     */
    Private $convertDataUtility = null;

    /**
     * constructor
     *
     * @return void
     */
    Public function __construct()
    {
			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
			$this->convertDataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\ConvertDataUtility');
    }

    /**
     * hasUserEditAccess
     *   called from EditorController
     *
     * @param string $strUsergroups
     * @param array $settings
     * @return boolean
     */
    Public function isUserInUsergroup( $strUsergroups , $settings )
    {
            // user is in no group means no user at all
			if( empty( $strUsergroups ) ) return false;

			// read flexform data and remove  empty fields
			$this->settings = $this->enrichSettingsWithFlexformData( $settings );
			 
            // no group limitations:
			if( empty( $this->settings['usergroup'] ) ) return true;

            // define affored groups from flexform as array
            $aAfforedGroup = explode( ',' , $this->settings['usergroup'] );
            // define users groups as array
			$aUsersGroups = array_flip( explode( ',' , $strUsergroups ) );
            
            // seek in affored groups for comparing users group and return true on match.
            foreach( $aAfforedGroup as $pidOk ){
                if( isset($aUsersGroups[$pidOk]) ) return true;
            }
            
            // return false if no match
            return false;
    }

    /**
     * appendRestrictions
     *  called from external plugin
     *  
     *  restriction = [ 1:new | 2:edit| 3:new+edit| 4:update | 5:new+update | 6:update+edit | 7:new+update+edit ]
     *  condition = SQL condition with joins
     *
     * @param array $aRecordset
     * @param array $settings
     * @param int $actionContext default is edit. [ 1:new | 2:edit | 4:update ]
     * @return array
     */
    Public function appendRestrictions( $aRecordset , $settings , $actionContext = 2 )
    {
			// return data untouched if not called from editor plugin
            if( $settings['list_type'] != 'sdbadminer_edit'  ) return $aRecordset;
			
			$this->aRecordset = $aRecordset;
			$this->actionContext = $actionContext;

			// read flexform data and remove  empty fields
			$this->settings = $this->enrichSettingsWithFlexformData( $settings );

			// sql is used only for verifyClauseBySqlCall
			$this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
			
            $this->appendTableRestrictions( $this->settings );
            $this->appendFieldRestrictions( $this->settings );
			
			$this->sqlUtility->closeDatabase();
            
            return $this->aRecordset;
    }

    /**
     * verifyData
     *  called from ModelUtility
     *
     * @param array $aRecordset
     * @param array $settings
     * @return array empty array or filled with errors
     */
    Public function verifyData( $aRecordset , $settings )
    {
        $aErrors = [];
		$this->settings = $this->enrichSettingsWithFlexformData( $settings );
        
		// return no errors if no restrictions
        if( !is_array($this->settings['restrictfield']) ) return $aErrors;
			
        $this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
        
        // transform the 1-dim text-array to a 2-dim recorset-array and append data-type
        foreach( $aRecordset as $fieldname => $value ){
            $fdlProp = $this->sqlUtility->getFieldProperties( $fieldname , $this->settings['tablename'] , $this->settings['dbname'] );
            $this->aRecordset[$fieldname]['type'] = $fdlProp['DATA_TYPE'];
            $this->aRecordset[$fieldname]['value'] = $value;
        }
        
        foreach( $this->settings['restrictfield'] as $ix => $fieldname ){
            
            // only verify the incoming fields 
            if( !isset($this->aRecordset[$fieldname]) ) continue;
            
            if(  !isset($this->settings['restriction'][$ix]) || !isset($this->settings['condition'][$ix]) ) continue;
            if( empty($this->settings['condition'][$ix]) ) continue;
            
            // is the actual action included in restrict-actions?
            $aIncludedActions = $this->convertDataUtility->integer2arrBinarys( $this->settings['restriction'][$ix] );
            $setAsLocked = isset($aIncludedActions[$this->actionContext]);
            if( !$setAsLocked ) continue;
            
            // transform the conditions string to array and replace patterns with field-values
            $fdlProp = $this->sqlUtility->getFieldProperties( $fieldname , $this->settings['tablename'] , $this->settings['dbname'] );
            $aJoins = $this->getParsedRestrictionsArray( $this->settings['condition'][$ix] );
            if( !isset($aJoins['body']) ) continue;
            // if is locked append error message to specific fieldname
            $isLocked = $this->verifyClauseBySqlCall( $aJoins );
            if($isLocked) $aErrors[$fieldname] = 'verboten[' . trim( $this->aRecordset[$fieldname]['value'] ) .'] ';
        }
        
        $this->sqlUtility->closeDatabase();
        
        return $aErrors;
    }

    /**
     * enrichSettingsWithFlexformData
     *
     * @param array $settings
     * @return array
     */
    Private function enrichSettingsWithFlexformData( $settings )
    {
			// read flexform data and remove  empty fields
			$rawPiSettings = $this->flexdataUtility->getFlexformData( $settings['pluginUid'] );
			$allPiSettings = $this->flexdataUtility->reorganizeFlexformData( $rawPiSettings );
			foreach($allPiSettings as $name => $content ) $settings[$name] = $content;
			return $settings;
    }

    /**
     * appendTableRestrictions
     *
     * @param array $allPiSettings
     * @return array
     */
    Private function appendTableRestrictions( $allPiSettings )
    {
            $aRestriction = [];
            if( $this->actionContext == 2 && !empty($allPiSettings['restrictedit']) ) {
                $aJoins = $this->getParsedRestrictionsArray( $allPiSettings['restrictedit'] );
                if( isset($aJoins['body']) ) $aRestriction['locked'] = $this->verifyClauseBySqlCall( $aJoins );
            
                // if debugger ADDITIONAL DEBUG INFOS
                $aRestriction = $this->appendJoinsForDebug( $aJoins , $aRestriction );
            }
            
            if( !empty($allPiSettings['restrictdelete']) ) {
                $aJoins = $this->getParsedRestrictionsArray( $allPiSettings['restrictdelete'] );
                if( isset($aJoins['body']) ) $aRestriction['undeleteable'] = $this->verifyClauseBySqlCall( $aJoins );
                
                // if debugger ADDITIONAL DEBUG INFOS
                $aRestriction = $this->appendJoinsForDebug( $aJoins , $aRestriction );
            }

            if( count($aRestriction) ) $this->aRecordset['record_restriction'] = $aRestriction;
            
            return true;
    }

    /**
     * appendJoinsForDebug
     *
     * @param array $aJoins
     * @param array $aToAppend
     * @return array
     */
    Private function appendJoinsForDebug( $aJoins , $aToAppend = [] )
    {
            // if debugger is enabled: ADDITIONAL DEBUG INFOS: additionaly deliver the sql-request as array
            if( !$this->settings['debugprint'] ) return $aToAppend;
            foreach( $aJoins['body'] as $x => $body ){
                $aToAppend['joins'][$x]['body'] = $body;
                if( $aJoins['join'][$x] ) $aToAppend['joins'][$x]['join'] = $aJoins['join'][$x];
            }
            return $aToAppend;
    }

    /**
     * appendFieldRestrictions
     *
     * @param array $allPiSettings
     * @return array
     */
    Private function appendFieldRestrictions( $allPiSettings )
    {
			// return data untouched if no restrictions
			if( !is_array($allPiSettings['restrictfield']) ) return false;
			
			foreach( $allPiSettings['restrictfield'] as $ix => $fieldname ){
                if(  !isset($allPiSettings['restriction'][$ix]) || !isset($allPiSettings['condition'][$ix]) ) continue;
                
                $aIncludedActions = $this->convertDataUtility->integer2arrBinarys( $allPiSettings['restriction'][$ix] );
                $setAsLocked = isset($aIncludedActions[$this->actionContext]); // is the actual action included in restrict-actions?
                
                $this->aRecordset[$fieldname]['restriction'] = $this->getFieldRestrictions( $allPiSettings['condition'][$ix] , $setAsLocked );
			}
			return true;
    }

    /**
     * getFieldRestrictions
     *
     * @param string $statement
     * @param boolean $includeLocking it is possible to select only date-ranges without lock eg. for new records
     * @return array
     */
    Private function getFieldRestrictions( $statement , $includeLocking = true )
    {
            // no restriction for this field
            if( empty($statement) ) return;
            
            // transform the conditions string to array and replace patterns with field-values
            $aJoins = $this->getParsedRestrictionsArray( $statement );
            
            // something went wrong:
            if( !isset($aJoins['body']) ) return;
            
            // DATE RANGE: get date-range out of INTERVAL-clause: 'pastDays' and 'futureDays'
            $aMain = $this->getDateIntervals( $aJoins['body'] );
            
            // if locking is enabled: VERIFY CLAUSE BY SQL: create SQL - query to execute from array $aJoins
            if( $includeLocking ) $aMain['locked'] = $this->verifyClauseBySqlCall( $aJoins );
            
            // if debugger ADDITIONAL DEBUG INFOS
            $aMain = $this->appendJoinsForDebug( $aJoins , $aMain );

            return $aMain;
    }

    /**
     * getDateIntervals
     *  get date-range out of INTERVAL-clause: 'pastDays' and 'futureDays'
     *
     * @param array $aJoinsBody
     * @param array $aMain optional passthrough
     * @return array
     */
    Private function getDateIntervals( $aJoinsBody , $aMain = [] )
    {
            if( !is_array($aJoinsBody) || !count($aJoinsBody) ) return $aMain;
            foreach( $aJoinsBody as $strReplaced ){
                   $aIntervals =  $this->detectDateInterval( $strReplaced );
                   if( $aIntervals && $aIntervals['dayCode']){
                        $aMain[$aIntervals['dayCode']] = $aIntervals['value'];
                   }
            }
            return $aMain;
    }

    /**
     * detectDateInterval
     *
     * @param string $statement
     * @return array [ 'futureDays' , 'pastDays' ]
     */
    Private function detectDateInterval( $statement )
    {
                   $dayCode = [  '-' => 'pastDays' , '+' => 'futureDays' ];
                   $aInfo = [];
                   // search for INTERVAL
                   $inStrIntVal = strpos( $statement , 'INTERVAL' );
                   if( !$inStrIntVal ) return false;
                   // search for DAY, starting at position of INTERVAL
                   $inStrDay = strpos( $statement , 'DAY' , $inStrIntVal );
                   if( !$inStrDay ) return false;
                   
                   $strBefore = trim( substr( $statement , 0 , $inStrIntVal ) );
                   $aInfo['pre'] = trim( substr( $strBefore , strlen($strBefore)-1 , 1 ) );
                   $startPosOfBetween = $inStrIntVal + strlen('INTERVAL');
                   $aInfo['value'] = trim( substr( $statement , $startPosOfBetween , $inStrDay - $startPosOfBetween ) );
                  // if( $aInfo['value'] === '0' ) $aInfo['value'] += 0.1;
                   $aInfo['dayCode'] = $dayCode[ $aInfo['pre'] ];
                  // if( $aInfo['dayCode'] ) $aInfo[$aInfo['dayCode']] = $aInfo['value'];
                   return count($aInfo) ? $aInfo : false;
    }

    /**
     * verifyClauseBySqlCall
     *  create SQL-query from array $aJoins and execute
     *
     * @param array $aJoins
     * @return int
     */
    Private function verifyClauseBySqlCall( $aJoins )
    {
            if( !is_array($aJoins) || !isset($aJoins['body'])  || !count($aJoins['body']) ) return NULL;
            $strConditionList = '';
            foreach( $aJoins['body'] as $x => $sqlSequence ){
                    $strConditionList .= $sqlSequence;
                    if( $aJoins['join'][$x] && $sqlSequence ) $strConditionList .= $aJoins['join'][$x];
            }
            // execute the condition by sql and lock the field if return value is empty 
            if( $strConditionList ){
                $sqlQuery = 'SELECT ' . $strConditionList . '';
                $allRes = $this->sqlUtility->runQuery( $sqlQuery , $this->settings['dbname'] );
                if($allRes) $firstRow = current( $allRes ); // first row, index 0, 
                $firstField = $firstRow ? current($firstRow) : 0; // fieldname eg. result 
                return empty($firstField) ? 1 : 0;
            }
            // fallback: dont lock
            return NULL;
    }

    /**
     * getParsedRestrictionsArray
     *
     * @param string $statement
     * @return array
     */
    Private function getParsedRestrictionsArray( $statement )
    {
            if( empty($statement) ) return;
            // GENERAL: Create array aJoins and assign source data now
            $aJoins = $this->resolveJoins( $statement );
            // GENERAL: replace patterns with values from recordset
            $aJoins['body'] = $this->replacePatterns( $aJoins['body'] );
            return $aJoins;
    }

    /**
     * resolveJoins
     *
     * @param string $statement
     * @return string
     */
    Private function resolveJoins( $statement )
    {
			$aFullJoinName = [ 'o' => ' OR ' , 'a' => ' AND ' ];
            
            $lcStatements = strtolower($statement);
            $lcOrStatements = str_replace( ' and ' , ' or ' , $lcStatements );
            $aStats = explode( ' or ' , $lcOrStatements );
            
            $aJoins = [];
            $endpos = 0;
            for( $x = 0 ; $x <= count($aStats)-1 ; ++$x ){
                    $startpos = $endpos;
                    // append the length of joining ' AND ' or ' OR ' to position-counter
                    $endpos += strlen($aStats[$x]);
                    $aJoins['body'][$x] = substr( $statement , $startpos , strlen($aStats[$x]) );
                    $aJoins['join'][$x] = $aFullJoinName[ substr( $lcStatements , $endpos +1 , 1 ) ];
                    $endpos += strlen($aJoins['join'][$x]);
            }
            return $aJoins;
    }

    /**
     * replacePatterns
     *
     * @param array $aJoinsBody
     * @return array
     */
    Private function replacePatterns( $aJoinsBody )
    {
            foreach( array_keys($aJoinsBody) as $x ){
                    foreach( $this->aRecordset as $fldNam => $aFld ){
                        $value = $this->sanitizeSqlParameter( $aFld['value'] , $aFld['type'] );
                        $aJoinsBody[$x] = str_replace( '_' . $fldNam . '_' , $value , $aJoinsBody[$x]); 
                    }
            }
            return $aJoinsBody;
    }

    /**
     * sanitizeSqlParameter
     *
     * @param string $value
     * @param string $type
     * @return string value
     */
    Private function sanitizeSqlParameter( $value , $type )
    {
            if( $type == 'date' ) {
                $value = $this->convertDataUtility->translateDate($value);
            }
            return '"' . trim( $value , '"' ) . '"';
    }

}
