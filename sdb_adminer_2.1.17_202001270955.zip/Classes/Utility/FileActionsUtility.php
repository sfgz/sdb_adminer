<?php
namespace Sfgz\SdbAdminer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Utility\PathUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FileActionsUtility
 * 
 */

class FileActionsUtility {

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    protected $flexdataUtility = null;

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    protected $sqlUtility = null;

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
    }

    /**
     * fileHandler_upload
     *
     * @param string $selField
     * @param string $rawQueryString
     * @return string with /relativePath/filename.suffix OR false
     */
    Public function fileHandler_upload( $selField , $rawQueryString = '' )
    {
			// are upload-formfield and upload-path defined?
			if( empty($selField) || !$rawQueryString ) return false;

			// is any upload-action given?
			if( !isset($_FILES[ 'file' ]['tmp_name'][$selField]) || empty($_FILES[ 'file' ]['tmp_name'][$selField]) || empty($_FILES[ 'file' ]['name'][$selField]) ) return false;
			
			$typo3DocumentRoot = rtrim( realpath('') , '/' );
			$rawQueryString = rtrim( $rawQueryString , '/' );
			$displayDirectory = GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . '/' . $rawQueryString );
			if( !is_dir($displayDirectory) ) return false;
			
			$fileName = $_FILES[ 'file' ]['name'][$selField];
			
			if( file_exists( $displayDirectory . '/' . $fileName ) ) @unlink($displayDirectory . '/' . $fileName);
			$res = GeneralUtility::upload_copy_move( $_FILES[ 'file' ]['tmp_name'][$selField] , $displayDirectory . '/' . $fileName );
			if( $res ) return $rawQueryString . '/' . $fileName;
			return false;
    }

    /**
     * detectUnusedFilesAndDelete
     *  detect files to delete
     *  used by ModelUtility->triggerActionsAfterUpdate()
     *
     * @param string $uploadPath
     * @param a $dbname
     * @return array
     */
    Public function detectUnusedFilesAndDelete( $uploadPath , $dbname )
    {
			$this->sqlUtility->connectToDatabase( $dbname );
			$aDelFil = [];
			if( empty($uploadPath) ) return $aDelFil;
			
			// search in all plugins for fieldnames containing the same path
			$fieldsListContainingFilePath = $this->flexdataUtility->getFieldsContainingSpecificFilePath( $uploadPath );
			if( !count($fieldsListContainingFilePath) ) return $aDelFil;
			
			// search in all tables and records for filenames in possible fields 
			$aExistingFile = $this->detectRegisteredFiles( $fieldsListContainingFilePath );
			
 			// get all files in dir
			$typo3DocumentRoot = rtrim( realpath('') , '/' ) . '/';
 			$displayDirectory = rtrim( GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . trim($uploadPath) ) , '/' );
			$aFilesInDir =  glob( $displayDirectory . '/*.*' );
			if( !is_array($aFilesInDir) || !count($aFilesInDir) ) return $aDelFil;

			// detect files in dir that are not used by plugin and table-content
			foreach ( $aFilesInDir as $filename ) {
				$basename = pathinfo( $filename , PATHINFO_BASENAME );
				if( !count( $aExistingFile ) || !isset($aExistingFile[$uploadPath . '/' . $basename]) ){
					if( file_exists($filename) && filetype($filename) == 'file' ) {
						$aDelFil[$filename] = $uploadPath . '/' . $basename ;
					}
				}
			}
			$this->sqlUtility->closeDatabase();

			return $this->fileHandler_delete( $aDelFil );
    }

    /**
     * detectRegisteredFiles
     *
     * @param array $fieldsListContainingFilePath
     * @return array
     */
    Protected function detectRegisteredFiles( $fieldsListContainingFilePath )
    {
			$aExistingFile = [];
			foreach( $fieldsListContainingFilePath as $tablename => $aFieldlist ){
				foreach( $aFieldlist as $imgField => $unusedImgPath ){
					// select $imgField from $tablename where NOT $imgField = ''; collect imgnames as used
					$sqlQuery = 'select ' . $imgField . ' from ' . $tablename . ' where NOT ' . $imgField . ' = "";';
					$aResult = $this->sqlUtility->runQuery( $sqlQuery );
					if( !count($aResult) ) continue;
					foreach( $aResult as $row )  $aExistingFile[$row[$imgField]] = !isset($aExistingFile[$row[$imgField]]) ? 1 : $aExistingFile[$row[$imgField]] + 1;
				}
			}
			return $aExistingFile;
    }

    /**
     * fileHandler_delete
     *
     * @param array $aDelFil
     * @return void
     */
    Protected function fileHandler_delete( $aDelFil  )
    {
			if( !is_array($aDelFil) || !count($aDelFil) ) return;
			
			// delete unused files!
			foreach( array_keys($aDelFil) as $filename ) {
				if( file_exists( $filename ) ) unlink($filename);
			}
			return;
    }
 
}
