<?php
namespace Sfgz\SdbAdminer\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TemplateUtility
 * 
 */

class TemplateUtility {

	/**
	* @var array
	*/
	Private $settings = array();


    /**
     * setDefaultTemplates
     *  Creates the html-skeleton for HTML and AJAX calls.
     *  From Recordsets it needs only the first row and the amount.
     *
     * @param array $aRecordsets
     * @param array $settings
     * @return array
     */
    public function setDefaultTemplates( $aRecordsets , $settings )
    {
		if( !is_array($aRecordsets) ) return $settings;
		if( !count($aRecordsets) ) return $settings;
		
		$aFirstRecord = array_shift( $aRecordsets );
		$aKeys = array_keys($aFirstRecord);
		
			
		if($settings['pagetype'] == 1){ // render as single page

			foreach( $aFirstRecord as $fld => $cnt ) {
                    if( isset($cnt['value']) ){ $settings['leadtext'] = str_replace( '_' . $fld . '_' , $cnt['value'] , $settings['leadtext'] );}
			}
			if( !empty($settings['templating']) ) {
				$template = [
					'pager' => $settings['pager'],
					'template' => $settings['template']
				];
			}else{
				$template = [ 'pager' => '' , 'template' => '' ];
			}
		
			if( empty($template['pager']) ) {
				$firstField = current($aKeys);
				$template['pager'] = '_' . $firstField . '_ ';
			}
			if( empty($template['template']) ) {
				$template['template'] .= $settings['leadtext'] . ' ';
				foreach( $aKeys as $fld ){
					$template['template'] .= '<b>' . $fld . ':</b> _' . $fld . '_<br/>';
				}
			}
			// replace template in settings with new values AND replace linebreakes with br-tags
			foreach($template as $typ => $cnt ) $settings[$typ] = str_replace( "\n" , "<br>" , $cnt );

		}elseif($settings['pagetype'] == 2){ // render as select-field
			
			if( $settings[ 'fieldsdisplay' ] ) $aKeys = explode( ',' , $settings[ 'fieldsdisplay' ] );
			
			if( $settings[ 'linkfields' ] ) {
				$rawLinkfields = explode( ',' , $settings['linkfields'] );
				$settings['primary'] = $rawLinkfields[0];
			}else{
				$settings['primary'] = $aKeys[0];
			}

			$jsCode = 'if (this.value) actionSelectChange( this.value , \'jsUrl_'.$settings['pluginUid'].'_' . $settings['primary'] . '\' );';

			foreach( $aFirstRecord as $fld => $cnt ) {
                    if( isset($cnt['value']) ) $settings['leadtext'] = str_replace( '_' . $fld . '_' , $cnt['value'] , $settings['leadtext'] );
			}
            $template['headrow'] = $settings['leadtext'];
			$template['headrow'] .= '<select onchange="' . $jsCode . '" title="Auswahl aus: ' . $settings['tablename'] . '">';
 			$template['headrow'] .= '<option value="?id='.$settings['pagePid'].'" >Wählen...</option>';
			
 			$template['mainrow'] = '<option value="_' . $settings['primary'] . '_"_SELECTED_>';
			foreach( $aKeys as $fld ) $template['mainrow'] .= '_'.$fld.'_ ';
			$template['mainrow'] .= '</option>';
			
			$template['footrow'] = $template['mainrow'];
			$template['footrow'] .= '</select>';
			
			foreach($template as $typ => $cnt ) $settings[$typ] =  $cnt ;
			
		}else{ // render as list (eg. sortable table)

			if( !empty($settings['mainrow']) ) {
					if( !empty($settings['templating']) ) {
						return $settings;
					}else{
						$settings['headrow'] = '';
						$settings['mainrow'] = '';
						$settings['footrow'] = '';
					}
			}
			
			$template = [
				'headrow' => $settings['headrow'],
				'mainrow' => $settings['mainrow'],
				'footrow' => $settings['footrow']
			];
		
			$recordCounter = 'Anzahl Datens&auml;tze: _pages_';

			if( $settings['searchform'] != 1 ){ // AJAX builds a leadtext at is own
                    // FIXME if we do following replacement, then the links wont be rendered later on...
                    // foreach( $aFirstRecord as $fld => $cnt ) $settings['leadtext'] = str_replace( '_' . $fld . '_' , $cnt['value'] , $settings['leadtext'] );
                    $template['headrow'] = $settings['leadtext'];
            }
            
			if( empty($settings['headrow']) && empty($settings['mainrow']) ){
 				$template['headrow'] .= $settings['searchform'] == 1 ? '<span id="recordCounter'.$settings['pluginUid'].'" class="record_counter">' .$recordCounter . '</span>' : '';
				$template['headrow'] .= $settings['searchform'] == 1 || count($aRecordsets) < $settings['defaultPagerSize'] ? '' : $this->getDefaultTemplate_pagerForTable( $settings );
				$template['headrow'] .= '<table id="sortPagerTable'.$settings['pluginUid'].'" class="sortTable tx_sdbadminer">';
				$template['headrow'] .= '<thead>';
				$template['headrow'] .= '<tr>';
				foreach( $aKeys as $fld ){
					$template['headrow'] .= '<th>' . $fld . '</th>';
				}
				$template['headrow'] .= '</tr>';
				$template['headrow'] .= '</thead>';
				$template['headrow'] .= '<tbody>';
			}
			if( empty($settings['mainrow']) ){
				$template['mainrow'] = '<tr>';
				foreach( $aKeys as $fld ){
					$template['mainrow'] .= '<td>_' . $fld . '_</td>';
				}
				$template['mainrow'] .= '</tr>';
				$template['tablepager'] = $this->getDefaultTemplate_pagerForTable( $settings );
			}
			if( empty($settings['footrow']) && empty($settings['mainrow']) ){
				$template['footrow'] = $template['mainrow'];
				$template['footrow'] .= '</tbody>';
				$template['footrow'] .= '</table>';
				$template['footrow'] .= $settings['searchform'] == 1 ? '' : '<div class="record_counter"><hr/>' . $recordCounter . '</div>';
			}
			// replace template in settings with new values WITHOUT replacing linebreakes
			foreach($template as $typ => $cnt ) $settings[$typ] =  $cnt ;

		}
 		return $settings;
    }

    /**
     * getDefaultTemplate_pagerForTable
     *
     * @param array $settings [ pluginUid , rowsdisplay , [ optional: imagepath ] ]
     * @return array
     */
    public function getDefaultTemplate_pagerForTable( $settings )
    {
		if( !isset($settings['pluginUid']) || empty($settings['pluginUid']) ) return false;
		if( !isset($settings['rowsdisplay']) || empty($settings['rowsdisplay']) ) return false; //['rowsdisplay'] = '10,5,15,20,25,30,50,100';
		if( !isset($settings['defaultPagerSize']) || empty($settings['defaultPagerSize']) ) return false;
		
		if( !isset($settings['imagepath']) || empty($settings['imagepath']) ) $settings['imagepath'] = 'typo3conf/ext/sfgz_fetools/Resources/Public/Img/tablesorter_pager';

		$aPgs = explode( ',' , $settings['rowsdisplay'] );
		$defaultPagerSize = trim($aPgs[0]);
		sort($aPgs);
		$aOpts = [];
		foreach($aPgs as $rawPg ) $aOpts[trim($rawPg)] = '<option value="' . trim($rawPg) . '">' . trim($rawPg) . '</option>';
		$strOptions = implode( "\n" , $aOpts );
		
		$html = '<div id="pager_'.$settings['pluginUid'].'" class="pager">
			<div style="float:left;width:auto;"><img src="'.$settings['imagepath'].'/first.png" class="first"/><img src="'.$settings['imagepath'].'/prev.png" class="prev"/></div>
			<div class="pagedisplay"></div>
				<div style="float:left;width:auto;padding:0;margin:0;"><img src="'.$settings['imagepath'].'/next.png" class="next"/><img src="'.$settings['imagepath'].'/last.png" class="last"/>
					<select title="Seite Nr." class="gotoPage"></select>
					<select title="Anzahl Zeilen pro Seite" class="pagesize" name="pagesize" style="width:4em;">
						' . $strOptions . '<option value="all">Alle Zeilen</option>
					</select>
				</div>
			<div style="clear:left;"></div>
		</div>';
		
		$js = '<script>
			$(document).ready(function(){
				$("#sortPagerTable'.$settings['pluginUid'].'").tablesorter({
					dateFormat: "ddmmyyyy", 
					debug:false, 
					initWidgets:false, 
					headers : {
							".dateFormat-ddmmyyyy" : {
								sorter: "shortDate", 
								dateFormat: "ddmmyyyy" 
							} 
					}
				}).tablesorterPager({
					container: $("#pager_'.$settings['pluginUid'].'") , 
					size: ' . $defaultPagerSize . ' , 
					page: 0
				});
				
			});
		</script>';
		
		return '<!-- PAGER Nr:'.$settings['pluginUid'].' -->' . $html . $js . '<!-- /PAGER Nr:'.$settings['pluginUid'].' -->';
    }

    /**
     * templateTable
     * Fill the skeleton with data
     * Used only by HTML-calls, not by AJAX-call
     *
     * @param array $aRecordsets
     * @param array $settings
     * @return void
     */
    public function templateTable( $aRecordsets , $settings )
    {
		$this->settings = $settings;
		$templated = [];
		
		
		if( !is_array($aRecordsets) ) return $this->settings;
		if( !count($aRecordsets) ) return $this->settings;
		
		$aRep = array( '_page_' => 0 , '_pages_' => count($aRecordsets) );
		
		
		if($this->settings['pagetype'] == 1){ // render as single page
			
			if( !empty($this->settings['pager']) ) $this->settings['pagertemplated'] = $this->templatePager( $aRecordsets );
			
			if( empty($this->settings['template']) ) return $this->settings;
			
			$this->settings['templated'] = $this->renderRecords( $this->settings['template'] , $aRecordsets , $aRep , $templated );
		
		}else{ // render as list pagetype=1 OR as select-field pagetype=2
				

			if( $this->settings['headrow'] ){
				// first row
				$aFres['001'] = current($aRecordsets);
				$templated = $this->renderRecords( $this->settings['headrow'] , $aFres , $aRep , $templated );
			}

			// repeat last row with different template
			if( $this->settings['footrow'] ){
				// middle rows with all indizes
				$aLastRecord = array_pop( $aRecordsets );
				$templated = $this->renderRecords( $this->settings['mainrow'] , $aRecordsets , $aRep , $templated );
				$templated = $this->renderRecords( $this->settings['footrow'] , [ $aRep['_pages_'] => $aLastRecord ] , $aRep , $templated );

			}elseif( $this->settings['mainrow'] ){
				// middle rows with all indizes
				$templated = $this->renderRecords( $this->settings['mainrow'] , $aRecordsets , $aRep , $templated );
			}
			$this->settings['templated'] = $templated;
		}
		
		
		return $this->settings;
    }

    /**
     * templatePager
     *
     * @param array $aRecordsets
     * @return array
     */
    public function templatePager( $aRecordsets )
    {
			$aContetTemp = [];
			if( !is_array($aRecordsets) ) return $aContetTemp;
			if( !count($aRecordsets) ) return $aContetTemp;
			
			$aRep = array( '_page_' => 0 , '_pages_' => count($aRecordsets) );
			
			$aContetTemp[] = [
					'type' => 'Text' ,
					'value' => $this->settings['pager']
			];
			$aTemplated = $this->renderRecord_replacement( $aContetTemp , $aRecordsets , $aRep );
			return $aTemplated;
    }

    /**
     * renderRecords
     *
     * @param string $template
     * @param array $aRecordset
     * @param array $aRep
     * @param array $aTemplated
     * @return string
     */
    Private function renderRecords( $template , $aRecordset , $aRep , $aTemplated )
    {
// 		$template = str_replace( "\n" , "<br>" , $template );
		
		$aContetTemp = $this->splitTemplateForLinks( $template );
		
		return $this->renderRecord_replacement( $aContetTemp , $aRecordset , $aRep , $aTemplated );
    }

    /**
     * renderRecord_replacement
     * 
     * Replaces placeholders with variable-values 
     *  in text-junk-attributes 'value'
     * 
     * Appends the attribute 'selected' 
     *  to text-junks with attribute 'link'
     *  if they are selected
     *  used in Partials/JsLink.html
     *
     * @param array $aContetTemp
     * @param array $aRecordset
     * @param array $aRep
     * @param array $aTemplated
     * @return string
     */
    public function renderRecord_replacement( $aContetTemp , $aRecordset , $aRep , $aTemplated = array() )
    {
		$pageNumber = 0;
		foreach( $aRecordset as $idx => $row ) {// all rows include first row
			++$pageNumber;
			$aRep['_page_'] = $pageNumber;
			foreach( $aContetTemp as $tIx => $aTemlate ) {
				
				// copy raw template
				$aTemplated[$idx][$tIx]  =  $aTemlate;
				//continue;
				// replace page placeholders
				$aTemplated[$idx][$tIx]['value']  =  str_replace( array_keys($aRep) , $aRep ,  $aTemlate['value'] );
				
				// set selected-tag in actionSelect options-list FIXME
				if( 'SELECTED' == $aTemlate['name'] ){
					foreach( $row as $fld => $cnt ) {
						if( isset($cnt['selected']) && $cnt['selected'] ) {
							$aTemplated[$idx][$tIx]['value']  = str_replace( '_SELECTED_' , ' selected="1"' , $aTemplated[$idx][$tIx]['value'] );
							$aTemplated[$idx][$tIx]['selected'] = $cnt['selected'];
						}
					}
				}
				$aTemplated[$idx][$tIx]['value']  = str_replace( '_SELECTED_' , '' , $aTemplated[$idx][$tIx]['value'] );
				// set selected-tag in editable select options-list
				foreach( $row as $fld => $cnt ) {
					// replace variables placeholders
					if( isset($cnt['value']) ){
                        $aTemplated[$idx][$tIx]['value']  = str_replace( '_'.$fld.'_' , $cnt['value'] , $aTemplated[$idx][$tIx]['value'] );
                        if( $cnt['selected'] && $fld == $aTemlate['name'] ) $aTemplated[$idx][$tIx]['selected'] = $cnt['selected'];
					}
				}
				
			}
		}
		return $aTemplated;
    }

    /**
     * splitTemplateForLinks
     *
     * @param string $template
     * @return array
     */
    public function splitTemplateForLinks( $template )
    {
		$rawLinkfields = explode( ',' , $this->settings['linkfields'] );

		$aLinkFields = [ 'SELECTED' => 'SELECTED' ];
 		
		foreach( $rawLinkfields as $fld ) $aLinkFields[trim($fld)] = trim($fld);
		
		$aContetTemp = $this->splitTemplate( $template , $aLinkFields );
		
		return $aContetTemp;
    }

    /**
     * splitTemplateForLinks
     *
     * @param string $template
     * @param array $aSplitFieldNames
     * @return array
     */
    public function splitTemplate( $template , $aSplitFieldNames )
    {
		// linkfields: uid, nr
		
		// tableRow:   #_nr_ uid: _uid_ / Name: _Name_ 
		//    index:  |0|1 | 2    | 3 | 4             |
		//     type:  |T|L | T    | L | T             |
		//     name:     nr        uid
		//  linkPos:     1         11 
     
		// arrayContetTemplate: [ 
		//    0 => [ type=>Text , value=> '#'                          ] , 
		//    1 => [ type=>Link , value=> '_nr_'            , name=nr  ] ,
		//    2 => [ type=>Text , value=> ' uid: '                     ] , 
		//    3 => [ type=>Link , value=> '_uid_'           , name=uid ] ,
		//    4 => [ type=>Text , value=> ' / Name: _Name_ '           ] ];
		
		// store the position of SplitFieldNames (e.g. links) in $aLinkPos
		
		$linkType = 'JsLink';// $this->settings['pagetype'] == 2 ? 'Link' : 'JsLink';
		$aLinkPos = [];
		$maxLen = strlen($template);
		if( count($aSplitFieldNames) ){
			foreach( $aSplitFieldNames as $fieldname ) {
					$tag = '_' . $fieldname . '_';
					for( $X = 0 ; $X < $maxLen ; ++$X ){
						$xpos = strpos( $template , $tag , $X );
						if( $xpos === false ) break;
						$aLinkPos[ $xpos ] = $fieldname;
						$X = $xpos + strlen($tag);
					}
			}
		}
		ksort($aLinkPos);
		
		// assume splitted text junks and link-options to array $aContetTemp
		$lastPos = 0;
		if( count($aLinkPos) ){
			foreach( $aLinkPos as $linkPos => $fieldname ) {
					// if leading text define it
					if( $linkPos > $lastPos ) {
							$aContetTemp[] = [
									'type' => 'Text' ,
									'value' => substr( $template , $lastPos , $linkPos-$lastPos )
							];
					}
					// reset pointer for leading text in next loop
					$lastPos = $linkPos + strlen('_' . $fieldname . '_') ;
					
					// define as link
					$aContetTemp[] = [
							'type' => $linkType ,
							'name' => $fieldname ,
							'value' => '_' . $fieldname . '_'
					];
			}
		}
		
		// if trailing text define it. If no links, return one array-value
		if( $lastPos < $maxLen ){
				$aContetTemp[] = [
						'type' => 'Text' ,
						'value' => substr( $template , $lastPos )
				];
		}
		return $aContetTemp;
    }


}
