<?php
namespace Sfgz\SdbAdminer\Controller;
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Backend\Utility\BackendUtility;

/***
 *
 * This file is part of the "DB Adminer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@sfgz.ch>
 *  
 *  listAction can be filtered once by searchValue (searchField == foreignkey) 
 *       and can have one link selected (searchField == ownkey && searchValue)
 *  
 *  editAction can be filtered once by searchValue (searchField == foreignkey)
 *  
 *  if a filter-call is done then
 *  1. store link as selected if plugin has this link-name piNr-linkfieldName-searchValue [511]
 *  2. store data-filter if plugin is filtered piNr-foreignkey-searchValue OR? piNr-ownkey-searchValue
 *  
 *  HINT: The action is always 'list' and controller 'Filter' !! 
 *        The setting gets rewritten by getInputPost( 'tx_sdbadminer_main' ) 
 *        although this is 'tx_sdbadminer_edit'
 *  
 *  &tx_sdbadminer_main[field]=MitarbeiterID
 *  &tx_sdbadminer_main[content]=1
 *
 ***/

/**
 * EditorController
 */
class EditorController extends \Sfgz\SdbAdminer\Controller\FilterController
{

    /**
     * flexdataUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\FlexdataUtility
     */
    protected $flexdataUtility = null;

    /**
     * restrictionsUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\RestrictionsUtility
     */
    protected $restrictionsUtility = null;

    /**
     * modelUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\ModelUtility
     */
    protected $modelUtility = null;

    /**
     * sessionUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SessionUtility
     */
    protected $sessionUtility = null;
    
    /**
	 * initializeAction
	 *
	 */
	public function initializeAction()
	{
 			// General: get db-name, content-uid, page-uid from plugin flexform
 			
 			$this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');

			$this->flexdataUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\FlexdataUtility');
			$this->modelUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\ModelUtility');
			
			$this->settings['pluginUid'] = $this->configurationManager->getContentObject()->data['uid'];
			$this->settings['pagePid'] = $this->configurationManager->getContentObject()->data['pid'];
			$this->settings['list_type'] = $this->configurationManager->getContentObject()->data['list_type'];

			if( $this->settings['formtype']  < 2 || !isset($this->settings['ownkey']) || empty($this->settings['ownkey']) ){
				$this->settings['ownkey'] = $this->modelUtility->readPrimaryKey( $this->settings['dbname'] , $this->settings['tablename']  );
			}
			$this->settings = $this->flexdataUtility->reorganizeFlexformData( $this->settings );

			$this->sessionUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SessionUtility');

			// individual for EditorController
			$this->restrictionsUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\RestrictionsUtility');
			$this->settings['isUser'] = $this->restrictionsUtility->isUserInUsergroup( $GLOBALS['TSFE']->fe_user->user['usergroup'] , $this->settings );
			$this->getInputPost('tx_sdbadminer_main');

			// if this is the first Plugin then execute crud-action if affored, regardless the plugin-type (list or edit)
			$firstPage = $this->settings['pluginUid'] == $this->flexdataUtility->getFirstPluginUidOnPage( $this->settings['pagePid'] );
			$calingPuginUid = isset($this->settings['req']['callPlugin']) ? $this->settings['req']['callPlugin']: 0;
			if( $firstPage && $this->settings['isUser'] ){
				// boot model with config of the calling plugin and dispatch action - add errors
				$this->modelUtility->dispatchActions( $this->settings , $calingPuginUid );
			}
			// boot model with config for actual plugin - read errors
			$this->modelUtility->bootModel( $this->settings , $calingPuginUid );
			

    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
			if( $this->request->hasArgument('error') || ( !$this->settings['req']['save'] && $this->settings['startasnew'] ) ) {
				$this->getInputs();
			}
			
			$aOutFields = $this->modelUtility->getEditFields();

  			// Input and Error handling
			if( is_array($this->settings['req']['text']) && count($this->settings['req']['text']) ){// NEW 2019-01-23: loop through text instead of error
				
				foreach( $this->settings['req']['text'] as $editField => $value) {
				
					$aOutFields[$editField]['value'] = $aOutFields[$editField]['type'] == 'date' ? ( empty($value) ? date('d.m.Y') : trim($value) ) : $value;
					
					if( isset($this->settings['req']['error'][$editField]) ) {
                        $aOutFields[$editField]['error'] = $this->settings['req']['error'][$editField];
                    }
                    
				}
				
				if( isset($this->settings['req']['error']) && count($this->settings['req']['error']) ) {
					$this->addFlashMessage( 'Nicht erstellt' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				}
			}
			
			$this->settings['catched'] = $this->getValuesForNewFields( $aOutFields );
			// Set default-values. Required with settings "startAsNew" 
			if( $this->settings['startasnew'] ) {
                    foreach( $this->settings['catched'] as $editField => $catchedValue ) $aOutFields[$editField]['value'] = $catchedValue['value'];
			}
			
			$aRestrResult = $this->restrictionsUtility->appendRestrictions( $aOutFields , $this->settings , 1 );
			$this->view->assign('conf', [ 'settings' => $this->settings , 'Result'=>$aRestrResult ] );
			
			// templating css for header
 			$this->appendUserCss( $this->settings['css'] );
			$this->modelUtility->closeDatabase();
    }

    /**
     * initialize action edit
     *
     * @return void
     */
    public function initializeEditAction()
    {
			if( !$this->settings['isUser'] ) return;
				
			if( $this->settings['req']['save'] == 'new' ){
				$this->forward( 'new' , 'Editor' );
			}
			
			$startAsNew = !$this->settings['req']['save'] && $this->settings['startasnew'] && ( $this->settings['req']['searchField'] != $this->settings['foreignkey'] || !$this->settings['req']['searchValue'] );
 			if( $startAsNew ) {
					$arguments = [ 
						'callPlugin' => $this->settings['pluginUid'], 
						'text'     => [ 'Datum' => date( 'd.m.Y' ) ] , 
						'action'   => 'list' , 
						'save'     => 'new' , 
						'content'  => $this->settings['req']['searchValue'] , 
						'field'    => $this->settings['req']['searchField'] 
					 ];
					$this->forward( 'new' , 'Editor' , 'SdbAdminer' , $arguments );
 			}
			
			if( $this->settings['req']['callPlugin'] != $this->settings['pluginUid'] ){
                return;
			}
			
			if( $this->settings['req']['save'] == 'create' ){
				
				if( !$this->modelUtility->settings['dispatched'] ) {
					// can not be created, redirect back to new-form without initializing again (forward)
					$arguments = [ 
						'callPlugin' => $this->settings['pluginUid'], 
						'error'    => $this->modelUtility->settings['error'] , 
						'text'     => $this->modelUtility->settings['req']['text'] , 
						'action'   => $this->settings['req']['action'] , 
						'content'  => $this->settings['req']['searchValue'] , 
						'field'    => $this->settings['req']['searchField'] , 
						'save'     => 'new' 
					 ];
					// $this->settings['req']['error'] = $this->modelUtility->settings['error'];
					$this->forward( 'new' , 'Editor' , 'SdbAdminer' , $arguments );
				}
			}
    }

    /**
     * action edit
     * opens a edit-form, no data manipulation in this action
     *
     * @return void
     */
    public function editAction()
    {
			$redirect = false;
			// called from this plugin
			if( $this->settings['req']['callPlugin'] == $this->settings['pluginUid'] ){
			
					if( $this->settings['req']['save'] == 'save' ) {
						if( $this->modelUtility->settings['dispatched'] ) {
							$this->addFlashMessage( 'Gespeichert in Tabelle "' . $this->settings['tablename'] . '".'  , 'Gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
							$redirect = true;
							
						}else{
                            // error handling
							$txt = '' ;
							if( is_array($this->modelUtility->settings['error']) ){
								foreach($this->modelUtility->settings['error'] as $fld => $msg) $txt .= "\n" . $fld . ':' . $msg . ' ';
								$this->settings['verify']['error'] = $this->modelUtility->settings['error'];
							}
							$this->addFlashMessage( ' Datensatz in Tabelle "' . $this->settings['tablename'] . '" wurde nicht gespeichert.' . $txt , 'Nicht gespeichert!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
						}

					}elseif( $this->settings['req']['save'] == 'delete' ){
							$this->addFlashMessage( 'Gelöscht' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
							$redirect = true;
					
					}elseif( $this->settings['req']['save'] == 'create' ){
						if( $this->modelUtility->settings['dispatched']  ) {
							$this->settings['req']['text'] = $this->modelUtility->settings['req']['text'] ;
							$this->settings['req']['searchValue'] = $this->modelUtility->settings['lastCreatedUid'];
							$this->addFlashMessage( 'Erstellt: #' . $this->modelUtility->settings['lastCreatedUid'] . ' ' , 'Erstellt' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
							$redirect = true;
						}
					}
			}

			// Result: execute the SQL-Statements
			$aResult = $this->modelUtility->getDataFromRequest( $this->settings['req'] );
			$strQueryInfo = isset($this->modelUtility->settings['sqlAction']) ? $this->form_lang_decode( $this->modelUtility->settings['sqlAction'] ) : '';
			if( empty($strQueryInfo) ) $strQueryInfo = $this->form_lang_decode( $this->modelUtility->settings['sqlRequest'] );
			
			
			if( $this->settings['formtype'] == 1 ){
				// as edit form: 
				if( count($aResult) ) $aResult = $this->prepareEditFields( current( $aResult ) );
				
				// for new records, we can add default value from flexform, possibly depending on calling link
				$this->settings['catched'] = $this->getValuesForNewFields( $aResult );
			}else{
				// as optiongroups
				if( $this->settings['req']['save'] == 'new' ||  $this->settings['req']['save'] == 'delete' ) {
					// as optiongroup: hide on new+create-action
					$aResult = [];
					$this->settings['req']['searchValue'] = '';
				}else{
					// as optiongroup: build query from oppositetable, oppositefield, oppositelabel
					$foreignFldProps = $this->modelUtility->sqlUtility->getFieldProperties( $this->settings['oppositelabel'] , $this->settings['oppositetable'] , $this->settings['dbname'] );;
					$pluginLabel = $foreignFldProps['COLUMN_COMMENT'] ? $foreignFldProps['COLUMN_COMMENT'] : $this->settings['oppositelabel'];
					$aResult = $this->mergeMmTableWithParent( $aResult );
                    if( is_array($aResult) && count($aResult) ) {
                        foreach( $aResult as $rRow ){
                            if( $rRow['checked'] ) $aChecked[$rRow[$this->settings['keytooppositetable']]] = $rRow['label'];
                        }
                    }
					// for vertical display only: translate rows to em
					if( $this->settings['orientation'] == 1 && is_numeric( $this->settings['maxsize']) ) $this->settings['maxsize'] = $this->settings['maxsize'] * 1.5;
				}
			}
			
			$this->modelUtility->closeDatabase();
			
			if( $redirect && $this->settings['pagePid'] != $this->settings['topage'] ){
				$this->redirectToURI( '?id=' . $this->settings['topage'] );
			}

			$sess = $this->sessionUtility->getData();
			$aRestrResult = $this->restrictionsUtility->appendRestrictions( $aResult , $this->settings , 2 );
			
			$this->view->assign('conf', [ 'prependList'=>['fieldLabel'=>$pluginLabel,'checkedList'=>$aChecked],  'sess'=>$sess,  'settings' => $this->settings ,  'Query'=>  $strQueryInfo , 'Result'=>$aRestrResult ] );
			
			// templating css for header
 			$this->appendUserCss( $this->settings['css'] );
    }


    /**
     * getValuesForNewFields
	 * build select-fields from SQL-Query or incoming values
     *
     * @param array $aRecordset
     * @return array
     */
    Protected function getValuesForNewFields( $aRecordset )
    {
		$aCatchedContents = [];
		$catchFields = [];

		if( !isset($this->settings['catchtofield']) || !count($this->settings['catchtofield']) ) return $aCatchedContents;
		
		//sanitize incoming db, because it has built with default values
		foreach( $aRecordset as $filedname => $cntArr ){
                if( empty($cntArr['value']) ) unset( $aRecordset[$filedname]);
		}
        $replaceDB = count($aRecordset) ? $aRecordset: [];
        if( $this->settings['req']['searchField'] && $this->settings['req']['searchValue'] ){
            $replaceDB[$this->settings['req']['searchField']] = [ 'value' => $this->settings['req']['searchValue'] , 'source' => 'pi' ];
        }
		
		// detect the new value to set for field (toField) 
		// - either from fields to catch (fromField) OR from SELECT query
		// - OR from request field
		foreach( $this->settings['catchtofield'] as $ix => $toField ){
			
			$rawQueryString = trim( $this->settings[ 'catchfromfield' ][$ix] );
			$aSqlParts = explode( ';' , $rawQueryString );
			foreach( $aSqlParts as $sqlPart ){
                    $posOfSelect = strpos( ' ' . $sqlPart , 'SELECT' );
                    if( $posOfSelect ){
                        // the replace value is built with SELECT
                        $aRawQueries[$toField] = $sqlPart ;
                        
                    }else{
                        $aRawFlds = explode( ',' , $sqlPart );
                        foreach( $aRawFlds as $rawField ){
                            $fromField  = trim( $rawField );
                            if( substr( $fromField , 0 , 1 ) == '"' || substr( $fromField , 0 , 1 ) == "'" ){
                                // the replace Value is a static text or numeric value between Text-enclosures " or '
                                $maskedValue = str_replace( "'" , '"' , $fromField );
                                $aCatchedContents[$toField] = ['value'=> str_replace(  '"' , '' , $maskedValue ) , 'source'=> 'fieldvalue' ] ;
                                // can be replaced later by field-value!
                                
                            }else{
                                // the replace value comes from a field value, either from recordset or from calling link. store the fieldname in a array
                                $catchFields[$toField][$fromField] = $fromField ;
                                
                            }
                        }
                    }
			}
			
		}
		
		// Replacing fieldnames with values: 
		$isCatched = 0;
		if( count($catchFields) ){
			// if we are in edit-mode OR startAsNew, get values from actual recordset or user-data
            foreach( $catchFields as $toField => $fldArr ){
                foreach($fldArr as $fromField ) {
                    if(isset($replaceDB[$fromField]) ) {
                        $aCatchedContents[$toField] = ['value'=>$replaceDB[$fromField]['value'] , 'source'=> 'db' ];
                        ++$isCatched;
                    }else{
                        $feUserData = $this->sessionUtility->getFeUserData( $fromField );
                        if(!$feUserData) continue;
                        $aCatchedContents[$toField] = ['value'=> $feUserData , 'source'=> 't3' ];
                        ++$isCatched;
                    }
                }
            }

		}elseif( $this->settings['req']['searchField'] ){
			// add-new mode. no recordset given. Get values from incoming links if they match with linknames in flexform
			if( count($catchFields) ){
				foreach( $catchFields as $toField => $fldArr ){
					foreach($fldArr as $fromField ) {
						if( $this->settings['req']['searchField'] == $fromField ) {
							$aCatchedContents[$toField] = ['value'=>$this->settings['req']['searchValue'] , 'source'=> 'pi'  ] ;
							++$isCatched;
						}
					}
					
				}
			}
		}

		// replace placeholders with values and build array for output
		if( isset($aRawQueries) && is_array($aRawQueries) && count($aRawQueries) ){
			foreach( $aRawQueries as $toQueryField => $queryString ){
				// replace with recordsets or request-value
				if( count($replaceDB) ){
					foreach( $replaceDB as $tcField => $aFldRes ){
						if( !isset($catchFields[$tcField]) ) continue;
						$queryString = str_replace( '_' . $tcField . '_' , $aFldRes['value'] , $queryString );
					}
				}
				$qResult = $this->modelUtility->runQuery( $queryString , $this->settings['dbname'] );
				if( $qResult && count($qResult) ) {
					$firstResult = array_shift($qResult);
					$a2str = is_array($firstResult) ? implode( '' , $firstResult ) : $firstResult; 
					$aCatchedContents[$toQueryField] = ['value'=> $a2str, 'source'=> 'query'   ];
				}
				
			}
		}

		return $aCatchedContents;
    }


    /**
     * prepareEditFields
	 * build select-fields from SQL-Query settings.selector.1-4
	 * merge editfields with Result
	 * more than one RS possible
     *
     * @param array $aRecordset
     * @return array
     */
    Protected function prepareEditFields( $aRecordset )
    {
			// detect PrimaryKey
			$this->settings['primary'] = $this->settings['ownkey'];
			// get PirmaryKey value
			$this->settings['indexvalue'] = $aRecordset[ $this->settings['primary'] ];

			$aOutFields = $this->modelUtility->getEditFields();
			if( count($aOutFields) ){
				foreach( $aOutFields as $editField => $cnt ){
					$aOutFields[$editField]['value'] = $this->modelUtility->renderEditFieldValueByType( $aRecordset[$editField] , $aOutFields[$editField]['type'] );
					if( isset($this->settings['verify']['error'][$editField]) ) $aOutFields[$editField]['error'] = $this->settings['verify']['error'][$editField];
				}
			}
			return $aOutFields;
			
    }


    /**
     * mergeMmTableWithParent
     *
     * @param array $aResult
     * @param string $keytooppositetable
     * @return array
     */
    Protected function getMmSelected( $aResult , $keytooppositetable )
    {
		$aSelected = [];
		// detect selected
		if( is_array($aResult) && count($aResult) ) {
			foreach( $aResult as $rRow ){
				$aSelected[ $rRow[ $keytooppositetable ] ] = 1;
			}
		}
		return $aSelected;
    }


    /**
     * mergeMmTableWithParent
     *
     * @param array $aResult
     * @return array
     */
    Protected function mergeMmTableWithParent( $aResult )
    {
		$aCheckboxeoptions = [];
		$outResult = [];
		
		$oppKeyNam = $this->settings['keytooppositetable']; // uid_foreign
		$oppFldNam = $this->settings['oppositefield'];
		$oppTabNam = $this->settings['oppositetable'];
		$oppLabNam = $this->settings['oppositelabel'];
		$ownKeyNam = $this->settings['ownkey']; // uid_local
		$aSelected = $this->getMmSelected( $aResult , $this->settings['keytooppositetable'] ); // uid_foreign
		
		if( $this->settings['req']['searchField'] != $this->settings['foreignkey'] ) return $outResult;
		
		
		// collect all possible entries and sort them
		$lstQquery = 'SELECT ' . $oppFldNam . ', ' . $oppLabNam . ' FROM ' . $oppTabNam . ' ORDER BY ' . $oppLabNam . ';' ;
		$aFullList = $this->modelUtility->runQuery( $lstQquery , $this->settings['dbname'] );
		if( is_array($aFullList) && count($aFullList) ){
			foreach( $aFullList as $ix => $row ){
				$aCheckboxeoptions[ $row[$oppLabNam] . '.' . $ix ] = [
					'label' => $row[$oppLabNam] , 
					'option' =>$row[$oppFldNam] , 
					'checked' => isset($aSelected[$row[$oppFldNam]]) ? 1 : 0 
				];
				if($ownKeyNam) $aCheckboxeoptions[ $row[$oppLabNam] . '.' . $ix ][$ownKeyNam] = $this->settings['req']['searchValue'];
				if($oppKeyNam) $aCheckboxeoptions[ $row[$oppLabNam] . '.' . $ix ][$oppKeyNam] = $row[$oppFldNam];
			}
		}
		
		if( !count($aCheckboxeoptions) ) return $aCheckboxeoptions;
		
		foreach( $aCheckboxeoptions as $row ) $outResult[ $row['option'] ] = $row;
		
		return $outResult;
    }

    /**
     * getInputPost
     *
     * @param string $pluginname
     * @return void
     */
    Protected function getInputPost( $pluginname  )
    {
				$req = GeneralUtility::_GET($pluginname);
				$post = GeneralUtility::_POST($pluginname);

				$arg = [];
				$arg['pluginUid'] = $this->settings['pluginUid'];
				$arg['req'] = 'GET_POST';
				if ($req['req']) $arg['req'] = trim($req['req']);
				
				if( is_array($post) && count($post) ) foreach( $post as $i => $c ) $req[$i] = $c;
				if ($req['callPlugin']) $arg['callPlugin'] = $req['callPlugin'];
				
				if ($req['pluginUid']) $arg['pluginUid'] = trim($req['pluginUid']);
				if ($req['field']) $arg['searchField'] = trim($req['field']);
				if ($req['content']) $arg['searchValue'] = html_entity_decode( trim($req['content']) ) ;
				if ($req['action']) $arg['action'] = trim($req['action']);
				if ( $req['save'] ) {
					$arg['save'] = trim($req['save']);
				}elseif( $req['new'] ) { 
					$arg['save'] = trim($req['new']); 
				}
				if ($req['text']) $arg['text'] = $req['text'] ;
				if ($req['error']) $arg['error'] = $req['error'];
				$this->settings['req'] = $arg;
    }

}
 
