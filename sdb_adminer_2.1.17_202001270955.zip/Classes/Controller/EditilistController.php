<?php
namespace Sfgz\SdbAdminer\Controller;
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Backend\Utility\BackendUtility;

/***
 *
 * This file is part of the "DB Adminer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@sfgz.ch>
 *  
 * Class to build models from csv-files over flat tables
 * 
 ***/

/**
 * EditlistController
 */
class EditlistController extends \Sfgz\SdbAdminer\Controller\FilterController
{

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbAdminer\Utility\SqlUtility
     */
    protected $sqlUtility = null;
    
    /**
	 * initializeAction
	 *
	 */
	public function initializeAction()
	{
 			$this->sqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbAdminer\\Utility\\SqlUtility');
    }

    /**
     * action select
     *
     * @return void
     */
    public function selectAction()
    {
            $arg['tableindex'] = 0;
            if( $this->request->hasArgument('tableindex') ) $arg['tableindex'] = $this->request->getArgument('tableindex');
            
			$aTables = $this->getTablesList();
			
			$this->view->assign('tableslist', $aTables );
			$this->view->assign('tableindex', $arg['tableindex'] );
			$this->view->assign('piUid', $this->configurationManager->getContentObject()->data['uid'] );
    }

    /**
     * action edlist
     *
     * @param string $tableindex
     * @return void
     */
    public function edlistAction( $tableindex )
    {
			$aTables = $this->getTablesList();
			$sTablename = $tableindex ?  $aTables[$tableindex] : '';
			
			$tableReferences = $this->getDbFieldPropertiesOfMainTables($this->settings['dbname'] );
			$tabReference = [];
			// add choosen table (a 1:n list table)
			if( isset($tableReferences['tables'][$sTablename]) ) $tabReference['choosen'] =  $tableReferences['tables'][$sTablename] ;
			
			$this->view->assign('tableReferences', $tabReference['choosen'] );

			$this->view->assign('tableIndex', $tableindex ? $tableindex : 0 );
			$this->view->assign('tablename', $sTablename );

			$this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
			$aQueryResult = $this->sqlUtility->runQuery( 'SELECT * FROM ' . $this->settings['dbname'] . '.' . $sTablename . ';');
			// index has to be uid!
			$aData = [];
			$indexFieldname = $tabReference['choosen']['LOCAL_INDEX'];
			if(empty($indexFieldname)){
                if( count($aQueryResult) ) $firstRow = current($aQueryResult);
                if( is_array($firstRow) ) $indexFieldname = array_shift( array_keys($firstRow) );
			}
			if(empty($indexFieldname)){
                $aData = $aQueryResult;
			}else{
                foreach($aQueryResult as $ix => $row ) $aData[ $row[$indexFieldname] ]= $row; 
            }
			$this->view->assign('data', $aData );
			
			$this->settings['size'] = is_numeric( $this->settings['maxsize']) ? $this->settings['maxsize'] * 1.8 : 0;
			$this->view->assign('settings', $this->settings );
			$this->view->assign('piUid', $this->configurationManager->getContentObject()->data['uid'] );
			
    }

    /**
     * getTablesList
     *
     * @return array
     */
    Private function getTablesList()
    {
		if( $this->settings['allpossibletables'] ){
            $this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
            $aDbTables = $this->sqlUtility->readOnlyTabels( $this->settings['dbname'] );
            if( is_array($aDbTables ) ){
                foreach($aDbTables as $tabnam){
                    $aFieldDefaults[$tabnam] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $this->settings['dbname'] ) ;
                    if( count($aFieldDefaults[$tabnam]) != 2 ) unset($aDbTables[$tabnam]);
                }
            }
		}else{
            $aDbTables = explode( ',' , $this->settings['edittables'] );
		}
        array_unshift($aDbTables,'Wählen...');
        return $aDbTables;
    }

    /**
     * getDbFieldPropertiesOfMainTables
     *
     * @param string $dbname
     * @return array
     */
    Private function getDbFieldPropertiesOfMainTables( $dbname )
    {
			if( !$this->sqlUtility || !$dbname ) return [ 'fieldDefinition' => null , 'countAllTables' => null , 'database' => null ];
			
			$dbInfo = $this->getFieldInfosFromDB( $dbname );
			$aFieldDefaults = $dbInfo['properties'];
			
			// append index with unique-keys from KEY_COLUMN_USAGE-definition
            if( is_array($dbInfo['uniques']) ){
                foreach( $dbInfo['uniques'] as $fieldDef ){
                    if( isset( $aFieldDefaults[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ]) ){
                        $aFieldDefaults[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ]['IS_PRIMARY'] = $fieldDef['CONSTRAINT_NAME'];
                    }
                }
            }
            
            // Set constraintsDB.
            $constraintsDB = $this->detectReferences( $dbInfo['constraints'] , $aFieldDefaults );
            
            // detect references in main tables.
            if( is_array($aFieldDefaults ) ){
                foreach($aFieldDefaults as $tabnam => $tabDef ){
                    if( isset($constraintsDB[$tabnam]) ) { 
                        foreach( $tabDef as $fieldname => $fldDef ){
                            if( !isset($constraintsDB[$tabnam][$fieldname]) ) continue;
                            $aFieldDefaults[$tabnam][$fieldname]['REFERENCE_TO'] = $constraintsDB[$tabnam][$fieldname];
                            $aFieldDefaults[$tabnam]['REFERENCES'][$fieldname] = $constraintsDB[$tabnam][$fieldname]['REF_TABLE']; 
                        }
                        if( $aFieldDefaults[$tabnam]['REFERENCES'] ) $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'main';
                    }else{
                        $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'loose';
                    }
                }
            }
            
            if( is_array($constraintsDB ) ){
                foreach($constraintsDB as $tabnam => $tabDef ){
                    foreach($tabDef as $fldnam => $fldDef ){
                            if( isset($fldDef['LOCAL_INDEX']) ) {
                                    // 1:m table only, note this  nm relation in main table
                                    $aFieldDefaults[$tabnam]['REFERENCED_BY'][$fldnam] = $fldDef; 
                                    $aFieldDefaults[$tabnam]['REFERENCED_BY'][$fldnam]['REF_LABEL'] = ( $aFieldDefaults[$fldDef['REF_TABLE']][ $fldDef['REF_FIELD'] ]['COLUMN_COMMENT'] ? $aFieldDefaults[$fldDef['REF_TABLE']][ $fldDef['REF_FIELD'] ]['COLUMN_COMMENT'] : $fldDef['REF_FIELD'] );
                                    // note in 1:m table the index-field of the main-table
                                    $aFieldDefaults[$fldDef['REF_TABLE']]['REFERING_INDEX'] = $fldDef['LOCAL_INDEX'] ; 
                            }
                            // 1:m table only
                            if( isset($fldDef['NM_TABLE']) ) $aFieldDefaults[$fldDef['REF_TABLE']]['NM_TABLE'] = $fldDef['NM_TABLE'] ; 
                            // 1:n AND 1:m tables
                            $aFieldDefaults[$fldDef['REF_TABLE']]['REFERING_TABLE'] = $tabnam; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['LOCAL_INDEX'] = $fldDef['REF_INDEX']; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['LOCAL_FIELD'] = $fldDef['REF_FIELD']; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['TABLE_TYPE'] = isset($fldDef['NM_TABLE']) ? '1:m' : '1:n'; 
                    }
                    if( is_array($aFieldDefaults[$tabnam]['REFERENCED_BY']) ) $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'main';
                }
            }

			return [ 'tables' => $aFieldDefaults , 'views' => $dbInfo['views'] ];
			
    }
 
    /**
        * detectReferences
        *
        * @param array $aDBconstraints
        * @param array $aFieldDefaults
        * @return array
        */
    Private function detectReferences( $aDBconstraints , $aFieldDefaults )
    {
            // Set constraintsDB. Bundle references informations in 2 arrays to hold the mn-tables separate
            $constraintsDB = [];
            $constraintsMn = [];
            // detect the label field in 1:n tables
            $labelsDb = [];
            if( is_array($aFieldDefaults ) ){
                foreach($aFieldDefaults as $tabnam => $tabDef ){
                    foreach($tabDef as $fldnam => $fldDef ){
                        if( !isset($fldDef['IS_PRIMARY']) ) { $labelsDb[$tabnam] = $fldnam; break; }
                    }
                }
            }
            if( is_array($aDBconstraints ) ){
                foreach( $aDBconstraints as $fieldDef ){
                        if( $fieldDef['COLUMN_NAME'] == 'uid_local' ){ // nm - main table
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'localTable' ] =  $fieldDef['REFERENCED_TABLE_NAME'];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'localUid' ] = $fieldDef['REFERENCED_COLUMN_NAME'];
                        }elseif( $fieldDef['COLUMN_NAME'] == 'uid_foreign' ){ // mn - sibling
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'labelField' ] = $labelsDb[$fieldDef['REFERENCED_TABLE_NAME']];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'REF_TABLE' ] = $fieldDef['REFERENCED_TABLE_NAME'];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'REF_INDEX' ] = $fieldDef['REFERENCED_COLUMN_NAME'];
                        }else{ // not nm table - sibling or main
                            $constraintsDB[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ] = [ 
                                    'REF_TABLE'=> $fieldDef['REFERENCED_TABLE_NAME'] , 
                                    'REF_INDEX'=> $fieldDef['REFERENCED_COLUMN_NAME'] , 
                                    'REF_FIELD'=> $labelsDb[$fieldDef['REFERENCED_TABLE_NAME']] 
                            ];
                        }
                }
            }
            // Reset constraintsDB. move the mn-constraint to corresponding main table referred by uid_local
            if( is_array($constraintsMn ) ){
                foreach( $constraintsMn as $tabnam => $tabConst ){
                    $constraintsDB[ $tabConst['localTable'] ][ $tabConst['labelField'] ] = [ 'LOCAL_INDEX'=>$tabConst['localUid'] , 'NM_TABLE'=>$tabnam , 'REF_TABLE'=>$tabConst['REF_TABLE'] , 'REF_INDEX'=>$tabConst['REF_INDEX'] , 'REF_FIELD'=> $tabConst['labelField'] ];
                }
            }
            return $constraintsDB;
    }
 
    /**
        * getFieldInfosFromDB
        *
        * @param string $dbname
        * @return array
        */
    Private function getFieldInfosFromDB( $dbname )
    {
			if( !$this->sqlUtility->connectToDatabase( $dbname ) ) return [ 'properties' => null , 'constraints' => null , 'uniques' => null ];

			// read names of all main and sibling TABLES (with single unique) without M:N-TABLES and without VIEWS
            $dbTables = $this->sqlUtility->info['tables'];
            // read VIEWS
            $aDbViews = $this->sqlUtility->readViews( $dbname );
            // read M:N-TABLES
            $aDbMnTables = $this->sqlUtility->readMnTabels( $dbname );
            
            // add TABLE DEFINITIONS: 
			$aFieldDefaults = [];
            if( is_array($dbTables ) ){
                foreach($dbTables as $tabnam){
                    $aFieldDefaults[$tabnam] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $dbname ) ;
                }
            }
			$aViewFieldDefaults = [];
            if( is_array($aDbViews ) ){
                foreach($aDbViews as $tabnam => $viewDef ){
                    $aViewFieldDefaults[$tabnam] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $dbname ) ;
                }
            }
            
// 			// read REFERNCES
//             $sqlColUsage = 'SELECT * FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = "'.$dbname.'" AND REFERENCED_TABLE_SCHEMA';
//             $aConstraintsFromDB = $this->sqlUtility->runQuery( $sqlColUsage . ' = "'.$dbname.'";' );
// 
// 			// detect UNIQUE KEYS
//             $aUniquesFromDB = $this->sqlUtility->runQuery( $sqlColUsage . ' IS NULL;' );
            
			// read REFERNCES
            $sqlColUsage = 'SELECT * FROM information_schema.KEY_COLUMN_USAGE WHERE `TABLE_SCHEMA` = "'.$dbname.'"';
            
            // used for detectReferences( $aConstraintsFromDB , $aFieldDefaults )
            // contains nm or main tables, NO 1n tables AND NO UNIQUE-constraints
            $whrForeignKeys = ' AND `REFERENCED_TABLE_SCHEMA` = "'.$dbname.'";';
            $aConstraintsFromDB = $this->sqlUtility->runQuery( $sqlColUsage.$whrForeignKeys );

			// detect UNIQUE KEYS 
            $whrUniques = ' AND `REFERENCED_TABLE_SCHEMA` IS NULL AND `CONSTRAINT_NAME` LIKE "PRIMARY";';
            $aUniquesFromDB = $this->sqlUtility->runQuery( $sqlColUsage.$whrUniques );

			$this->sqlUtility->closeDatabase();
			
			$aResult = [
                'properties' => $aFieldDefaults , 
                'views' => $aViewFieldDefaults , 
                'constraints' => $aConstraintsFromDB , 
                'uniques' => $aUniquesFromDB  
			];

			return $aResult;
    }
    
} 
